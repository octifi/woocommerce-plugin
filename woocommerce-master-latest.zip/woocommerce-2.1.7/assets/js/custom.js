jQuery( document ).ready(function( $ ) {
    var testmode1 = $("select#woocommerce_octifi_testmode").val();
    var country = jQuery('select[name=woocommerce_octifi_select_the_country]');
	$( 'select#woocommerce_octifi_testmode' ).on( 'change', function() {
		var testmode = $(this).val();
		if (testmode == 'enable') {
			country.attr('disabled', 'disabled');
		}
		else{
			country.removeAttr("disabled");
		}
	});
    if (testmode1 == 'enable') {
	country.attr('disabled', 'disabled');		
    }
    else{
	country.removeAttr("disabled");
    }
});
