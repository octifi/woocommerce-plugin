<?php
/*
  Plugin Name: LatitudePay Payment
  Description: Allows payments by mobile phone with LatitudePay. Contact info@octifi.com if any queries.
  Author: LatitudePay 
  Author URI:  https://octifi.com/ 
  Version: 2.1.3
 */

//error_reporting(E_ALL);
//ini_set('display_errors', 'On');

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

define('OCTIFI_PLUGIN_URL', plugin_dir_url(__FILE__));
define('OCTIFI_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('OCTIFI_DEBUG', false);

include_once OCTIFI_PLUGIN_PATH.'vendor/octifienv/loader.php';

// load styles and scripts
add_action( 'init',  'octififunction_print_front_styling' );
function octififunction_print_front_styling(){
    $testmod=get_option('woocommerce_octifi_settings');
    wp_enqueue_style( 'octifi_main_style', plugins_url('/assets/css/front.css', __FILE__) ) ;

    wp_register_script( 'octifi_main_js', plugins_url('/assets/js/front.js', __FILE__), [ 'jquery' ] ) ;			
	wp_enqueue_script( 'octifi_main_js'  ) ;

    wp_register_script( 'OCTIFI_SCRIPT_SRC', getOctifiEnv('OCTIFI_SCRIPT_SRC',$testmod['testmode'],$testmod['select_the_country']), [ 'jquery' ]) ;
    wp_enqueue_script( 'OCTIFI_SCRIPT_SRC'  ) ;
}


/**
 * Initiate OctiFi Payment once plugin is ready
 */
add_action('plugins_loaded', 'octififunction_woocommerce_octifi_init');
function octififunction_woocommerce_octifi_init() {

    class WC_OctiFi extends WC_Payment_Gateway {

        public $domain;

        /**
         * Constructor for the gateway.
         */
        public function __construct() {
            $this->domain = 'octifi';

            $this->id = 'octifi';
            $this->icon = OCTIFI_PLUGIN_URL . 'assets/images/logo.png';
            $this->has_fields = false;
            $this->method_title = __('LatitudePay Payment', $this->domain);
            $this->method_description = __('Allows payments by mobile phone with OctiFi. Contact info@octifi.com if any queries.', $this->domain);
            
            // Define user set variables
            $this->title = $this->get_option('title');
            $this->description = $this->get_option('description');
            $this->testmode = $this->get_option('testmode');
            $this->api_key = $this->get_option('api_key');
	    $this->select_the_country = $this->get_option('select_the_country');	
            $this->private_api_key = $this->get_option('private_api_key');
            $this->payment_type = $this->get_option('payment_type');
            $this->payment_action = $this->get_option('payment_action');
	   if ($this->testmode == 'enable') {
            $this->description .= ' <span style="color:red">' . __('TEST MODE ENABLED', 'woocommerce-gateway-stripe') . '</span>';
            //$this->description = trim($this->description);
            $desc = trim($this->description);
            $symbol = get_woocommerce_currency_symbol();
            $des = str_replace("$",$symbol,$desc);
	    $des = str_replace("&#036;",$symbol,$desc);
            $this->description = $des;
            }

	    // Load the settings.
            $this->init_form_fields();
            $this->init_settings();
             if((isset($_REQUEST['checkout'])))
            {
            global $woocommerce;
            $checkout = $_REQUEST['checkout'] ;
            $search = 'failed?data';
            //$search="failed?data";

            if(strpos($checkout, $search)===0){
            $checkout_url = $woocommerce->cart->get_checkout_url();

            header('Location: '.$checkout_url);
            
            }
            }
            // Actions
            add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
            add_action('woocommerce_receipt_' . $this->id, array( $this, 'receipt_page' ));
            add_action('woocommerce_thankyou_' . $this->id, array($this, 'thankyou_page'));
            add_action('woocommerce_api_'. strtolower("WC_OctiFi"), array( $this, 'check_ipn_response' ) );
            add_action( 'woocommerce_order_status_completed', array( $this, 'order_completed'), 10, 1);
            add_action( 'woocommerce_admin_order_data_after_order_details', array( $this, 'admin_order_details'), 10, 3 );

            
        }

        

        /**
         * Initialize Gateway Settings Form Fields.
         */
        public function init_form_fields() {
			$symbol = get_woocommerce_currency();
            if(get_woocommerce_currency() =='SGD'){
                $val = 1;
            }
            elseif(get_woocommerce_currency() =='MYR'){
                 $val = 2;
            }
            else{
                $val = 1;
            }
			//echo "<pre>"; print_r($val); echo "</pre>"; die();
	    $field_arr = array(
                'enabled' => array(
                    'title' => __('Enable/Disable', $this->domain),
                    'type' => 'checkbox',
                    'label' => __('Enable LatitudePay Payment', $this->domain),
                    'default' => 'yes'
                ),
                'title' => array(
                    'title' => __('Title', $this->domain),
                    'type' => 'text',
                    'description' => __('This controls the title which the user sees during checkout.', $this->domain),
                    'default' => $this->method_title,
                    'desc_tip' => true,
                ),
                'testmode' => array(
                    'title' => __('Test mode', $this->domain),
                    'type' => 'select',
                    'default' => 'capture',
                    'options' => $this->getTestmode()
                ),
            	'select_the_country' => array(
                    'title' => __('Select the country', $this->domain),
                    'type' => 'select',
                    'default' => $val,
					'value' => $val,
                    'options' => $this->getcountry()
                ),
		    
               'hide_text_homepage' => array(
                    'title' => esc_html__('Home page text', 'octifi'),
                    'type' => 'checkbox',
                    'label' => esc_html__('Hide LatitudePay instalment text on home page', 'octifi'),
                    'default' => 'yes'
                ),
               'description' => array(
                    'title' => __('Instructions', $this->domain),
                    'type' => 'textarea',
                    'description' => __('Instructions that that the customer will see on your checkout.', $this->domain),
                    'desc_tip' => true,
                    'default' => __('<p class="checkout-text-octifi">Pay only '.get_woocommerce_currency_symbol().'<span id="checkout-newpayment">0</span> today with <img src="'.OCTIFI_PLUGIN_URL.'assets/images/logo.png"  style=" width:50%; max-width:50%; margin: 0px auto;"   > instalments</p><p id="OpenDialog">Learn more>></p>', $this->domain),
                ),
                
                'api_key' => array(
                    'title' => __('Public API Key', $this->domain),
                    'type' => 'text',
                ),
                'private_api_key' => array(
                    'title' => __('Private API Key', $this->domain),
                    'type' => 'text',
                ),
                'min_sum' => array(
                    'title' => __('Minimum Sum', $this->domain),
                    'type' => 'text',
                    //'default' => '0'
                ),
                'payment_type' => array(
                    'title' => __('Choose Payment Type', $this->domain),
                    'id' => 'payment_type',
                    'type' => 'payment_type',
                    'default' => 'redirect',
                    'options' => $this->getPaymentTypes()
                ),
                'payment_action' => array(
                    'title' => __('Payment Action', $this->domain),
                    'type' => 'select',
                    'default' => 'capture',
                    'options' => $this->getPaymentActions()
                ),
            );
	
            $this->form_fields = $field_arr;
        }
        
        public function getPaymentTypes() {
            $types = [
                'redirect' => __('Redirect', $this->domain),
                //'hosted' => __('Modal Popup', $this->domain),
            ];
            return $types;
        }
        public function getTestmode()
        {
             return [
                'enable' => __('enable', $this->domain),
                'disable' => __('disable', $this->domain),
            ];
        }
        public function getcountry()
        {
             return [
                '1' => __('Singapore', $this->domain),
                '2' => __('Malaysia', $this->domain),
            ];
        }
	    
        public function getPaymentActions() {
            return [
                'authorise' => __('Authorization', $this->domain),
                'capture' => __('Authorise & Capture', $this->domain),
            ];
        }
        
        public function generate_payment_type_html( $key, $value ) { 
            $payment_type = $this->settings['payment_type'];
            if (empty($payment_type)) {
                $payment_type = $value['default'];
            }
            $html = '<tr valign="top">
                    <th scope="row" class="titledesc">
                        <label for="woocommerce_octifi_'.$key.'">'. $value['title'].'</label>
                    </th>
                    <td class="forminp forminp-'.$key.'">
                    <fieldset>';
                    foreach($value['options'] as $type => $option) {    
                        $html .= '<label for="woocommerce_octifi_'.$key.'_'.$type.'">'
                                . '<input '
                                . 'type="radio" '
                                . 'name="woocommerce_octifi_'.$key.'" '
                                . 'id="woocommerce_octifi_'.$key.'_'.$type.'" '
                                . 'value="'.$type.'" '
                                . (($payment_type == $type) ? 'checked="checked"':'').'> '.$option.'</label>&nbsp;&nbsp;';
                    }
                    $html .= '</fieldset>
                    </td>
                </tr>';
            return $html;
        }

        /**
         * Process Gateway Settings Form Fields.
         */
	public function process_admin_options() {
            $this->init_settings();

            $post_data = $this->get_post_data();
            if (empty($post_data['woocommerce_octifi_api_key'])) {
                WC_Admin_Settings::add_error(__('Please enter OctiFi Public API Key', $this->domain));
            } else if (empty($post_data['woocommerce_octifi_private_api_key'])) {
                WC_Admin_Settings::add_error(__('Please enter OctiFi Private API Key', $this->domain));
            } else {
                foreach ( $this->get_form_fields() as $key => $field ) {
                    $setting_value = $this->get_field_value( $key, $field, $post_data );
                    $this->settings[ $key ] = $setting_value;
                }
                return update_option( $this->get_option_key(), apply_filters( 'woocommerce_settings_api_sanitized_fields_' . $this->id, $this->settings ) );
            }
	}
        
        /**
        * Receipt page
        *
        * @param  int $order_id Order ID.
        */
        public function receipt_page( $order_id ) {
            global $woocommerce;
            
            $order = wc_get_order($order_id);
            $order_data = $order->get_data();
            
            $order->delete_meta_data('OctiFi_Payment_Action');
            $order->add_meta_data('OctiFi_Payment_Action', $this->payment_action);
            $order->save_meta_data();
            
            $product_name = '';
            foreach ($order->get_items() as  $item) {
                $product_name .= $item->get_name().';'; 
            }
            $params['product_name'] = $product_name;
            
            /** v2.0.10 patch */
            if ( $this->payment_type == 'redirect'  || $this->payment_type == 'hosted'  ) {
                include_once OCTIFI_PLUGIN_PATH.'templates/redirect.php';
            } else {
                include_once OCTIFI_PLUGIN_PATH.'templates/modal.php';
            }
        }

        /**
         * Output for the order received page.
         */
        public function thankyou_page($order_id) 
        {
            global $woocommerce;
            
            $order = new WC_Order($order_id);
            $status = $order->get_status();
            if ($status == 'pending') {
                $style = "width: 100%;  margin-bottom: 1rem; background: #00ccb8; padding: 20px; color: #fff; font-size: 22px;";
            ?>
                <div class="payment-panel">
                    <div style="<?php echo $style?>">
                    <?php echo __('Your payment status is pending, we will update the status as soon as we receive notification from LatitudePay Payment System.', $this->domain) ?>
                    </div>
                </div>
            <?php
            } else if ($status == 'processing') {
                $style = "width: 100%;  margin-bottom: 1rem; background: green; padding: 20px; color: #fff; font-size: 22px;";
                $woocommerce->cart->empty_cart();
            ?>
                <div class="payment-panel">
                    <div style="<?php echo $style?>">
                    <?php echo __('Your payment is successful with LatitudePay Payment System.', $this->domain) ?>
                    </div>
                </div>
            <?php    
            } else if ($status == 'failed') {
                $style = "width: 100%;  margin-bottom: 1rem; background: indianred; padding: 20px; color: #fff; font-size: 22px;";
                $error_message = '';
                if (isset($_GET['octifierr'])) {
                    $error_message = base64_decode( esc_html(  $_GET['octifierr'] ) );
                    $woocommerce->cart->empty_cart();
                }
            ?>
                 <div class="payment-panel">
                    <div style="<?php echo $style?>">
                    <?php echo __('Your payment is failed with LatitudePay System. ', $this->domain) ?>
                    <?php if (!empty($error_message)) {?>
                        <?php echo $error_message ?>
                    <?php }?>
                    </div>
                </div>
            <?php
            } else if ($status == 'cancelled') {
                $style = "width: 100%;  margin-bottom: 1rem; background: indianred; padding: 20px; color: #fff; font-size: 22px;";
            ?>
                 <div class="payment-panel">
                    <div style="<?php echo $style?>">
                    <?php echo __('Your order is cancelled.', $this->domain) ?>
                    </div>
                </div>
            <?php
            }
        }
        
        public function admin_order_details( $order ){
            if ($order->get_payment_method() == $this->id) {

                $order_id = $order->get_id();
                
                $status_message = '';
                $status = '';
                
                if (isset($_GET['octifi_capture'])) {

                    $charge_id = get_post_meta( $order_id, 'OctiFi_Charge_Id', true );
                    if (!empty($charge_id)) {

                        $header = array(
                            "Accept" => "application/json",
                            "Content-Type" => "application/json",
                            "Authorization" => "Api-Key ".$this->private_api_key
                        );
                        
                        $params = array(
                            "charge_id" => $charge_id
                        );

                        /*
                        $options2 = array(
                            CURLOPT_URL => getOctifiEnv('OCTIFI_CHARGE_URL'), 
                            CURLOPT_RETURNTRANSFER => true, 
                            CURLOPT_HEADER => false, 
                            CURLOPT_SSL_VERIFYPEER => false, 
                            CURLOPT_POST => true, 
                            CURLOPT_POSTFIELDS => json_encode($params), 
                            CURLOPT_HTTPHEADER => $header
                        );
                        */

                         
                        $res = wp_remote_post(
                            getOctifiEnv('OCTIFI_CHARGE',$this->testmode,$this->select_the_country),
                            [
                                'timeout'     => 45,
                                'headers' => $header,
                                'body' =>  json_encode($params)
                            ]
                        );
                        if (is_wp_error( $res )) {
                         
                            $status_message = $res['response']['message'];
                            
                            $status = 'error';
                        } else {
                    
                            $result2 = json_decode($res['body'], true);
                            $this->log('trace_1');
                            $this->log($options2);
                            $this->log($result2);
                            if ($result2['status_code'] == 200) {
                                $message = $result2['message'];
                                if($message == 'This charge has already been captured') {
                                    $status_message = $message;
                                    $status = 'error';
                                } else {
                                    $charge_status = $result2['data']['ChargeStatus'];
                                    $message = __('Payment successful with OctiFi(Captured). Charge Status: '.$charge_status.'.', $this->domain);
                                    $status_message = __('Payment Captured Successfully.', $this->domain);
                                    $status = 'success';

                                    $order->delete_meta_data('OctiFi_Captured');
                                    $capture_status = 1;
                                    $order->add_meta_data('OctiFi_Captured', $capture_status);
                                    $order->save_meta_data();
                                }
                                            
                            } else {
                                $message = $result2['message'];
                                $status_message = $message;
                            }
                        }
                        $order->add_order_note( $message );
                    } else {
                        $status_message = __('Charge ID not found. ', $this->domain);
                        $status = 'error';
                    }
                } 
                
                $capture_url = get_edit_post_link($order_id).'&octifi_capture=1';
                
                $captured = (int)get_post_meta( $order_id, 'OctiFi_Captured', true );
                $charge_id = get_post_meta( $order_id, 'OctiFi_Charge_Id', true );
                $payment_action = get_post_meta( $order_id, 'OctiFi_Payment_Action', true );
                
                $style = "display: inline-block;margin-top: 20px;width: 100%;max-width: 100%;overflow: hidden;border-radius: 2px; text-align:center;";

                if (!empty($status_message)) {
                    $status_style = 'display: inline-block;margin-top: 30px;width: 100%;max-width: 100%;overflow: hidden; font-weight:600;';
                    if ($status == 'error') {
                        $status_style .= 'color: red;';
                    } else if ($status == 'success') {
                        $status_style .= 'color: green;';
                    }
                    echo '<div style="'.$status_style.'">'.$status_message.'</div>';
                }
                
                if ($captured == 1) {
                    $style .= 'border:3px solid green;';
            ?>
                <div style="<?php echo $style ?>">
                    <div style="padding: 10px; font-size: 16px; color: green">
                    <?php echo __('LatitudePay Payment Captured.', $this->domain) ?>
                    </div>
                </div>
            <?php
                } else {
                    $style .= 'border:2px solid orange;';
            ?>
                <div style="<?php echo $style ?>">
                    <div style="padding: 10px; ">
                        <a href="<?php echo $capture_url?>" class="button button-primary"><?php echo __('Capture LatitudePay Payment', $this->domain) ?></a>
                    </div>
                </div>
            <?php         
                }
            }
        }
        
        public function order_completed($order_id) {
            global $woocommerce;
            $payment_action = get_post_meta( $order_id, 'OctiFi_Payment_Action', true );

            if ($payment_action == 'authorise') {
                $order = new WC_Order($order_id);
                if ($order->get_payment_method() == $this->id) {
                    $charge_id = get_post_meta( $order->id, 'OctiFi_Charge_Id', true );
                    if (!empty($charge_id)) {
                        $header = array(
                            "Accept" => "application/json",
                            "Content-Type" => "application/json",
                            "Authorization" => "Api-Key ".$this->private_api_key
                        );
                        
                        $params = array(
                            "charge_id" => $charge_id
                        );
                        $res = wp_remote_post(
                            getOctifiEnv('OCTIFI_CHARGE',$this->testmode,$this->select_the_country),
                            [
                                'timeout'     => 45,
                                'headers' => $header,
                                'body' =>  json_encode($params)
                            ]
                        );
                        if ( is_wp_error( $res ) ) {
                    
                            $message = $res['response']['message'];
                        } else {
                  
                            $result2 = json_decode($res['body'], true);
                            $this->log('trace_2');
                            $this->log($options2);
                            $this->log($result2);
                            if ($result2['status_code'] == 200) {
                                $charge_status = $result2['data']['ChargeStatus'];
                                $message = __('Payment successful with OctiFi(Captured). Charge Status: '.$charge_status.'.', $this->domain);
                                $capture_status = 1;
                                $order->add_meta_data('OctiFi_Captured', $capture_status);
                                $order->save_meta_data();
                            } else {
                                $message = $result2['message'];
                            }
                        }
                        $order->add_order_note( $message );
                    }
                }
            }
            
        }
        
        public function check_ipn_response() {
            global $woocommerce;

            if(isset($_REQUEST['checkout'])) {
                $checkout = sanitize_text_field( $_REQUEST['checkout'] );

                $search = 'success?data';
                if (strpos($checkout, $search) !== false || $checkout == 'success') {
                    if ($checkout == 'success') {
                        $response['checkout_token'] = sanitize_text_field( $_REQUEST['checkout_token'] );
                        $response['merchant_order_id'] = sanitize_text_field( $_REQUEST['merchant_order_id'] );
                        $response['statuscode'] = sanitize_text_field( $_REQUEST['statuscode'] );
                    } else {
                        $data = str_replace($search, '', $checkout);
                        $jsonData =  base64_decode($data);
                        $response = json_decode($jsonData, true);
                    }

                    $error_message = '';

                    $order_id = $response['merchant_order_id'];
                    $order = new WC_Order($order_id);

                    if ($response['statuscode'] == 200) {

                        $checkout_token = $response['checkout_token'];

                        $order->delete_meta_data('OctiFi_Checkout_Token');
                        $order->add_meta_data('OctiFi_Checkout_Token', $checkout_token);
                        $order->save_meta_data();
   
                        $header = array(
                            "Accept" => "application/json",
                            "Content-Type" =>  "application/json",
                            "Authorization" => "Api-Key ".$this->private_api_key
                        );
                        
                        $is_capture = false;
                        if ($this->payment_action == 'capture') {
                            $is_capture = true;
                        }

                        $params = array(
                            "bill_total_amount" => $order->get_total(),
                            "bill_currency" => $order->get_currency(),
                            "bill_tax_amount" => $order->get_total_tax(), 
                            "is_capture" => $is_capture
                        );
                        $res = wp_remote_post(
                            getOctifiEnv('OCTIFI_CREATE',$this->testmode,$this->select_the_country).$checkout_token."/",
                            [
                                'timeout'     => 45,
                                'headers' => $header,
                                'body' =>  json_encode($params)
                            ]
                        );  
                         if ( is_wp_error( $res ) ) {
                            $error_message = $res['response']['message'];
                        } else {
                        
                            $result = json_decode($res['body'], true);
                            $this->log('trace_3');
                            $this->log($options);
                            $this->log($result);
                            if ($result['status_code'] == 200) {
                                $order->delete_meta_data('OctiFi_Charge_Id');
                                $order->delete_meta_data('OctiFi_Txn_Number');
                                $order->add_meta_data('OctiFi_Charge_Id', $result['data']['charge_id']);
                                $order->add_meta_data('OctiFi_Txn_Number', $result['data']['order_payment_details']['data']['txn_number']);
                                $order->save_meta_data();
                                
                                if ($is_capture) {
                                    $params = array(
                                        "charge_id" => $result['data']['charge_id']
                                    );
                                     
                                    
                                    $OctiFi_Charge_Id = $result['data']['charge_id'];
                                    $res = wp_remote_get(
                                        getOctifiEnv('OCTIFI_CHARGE_DETAIL',$this->testmode,$this->select_the_country).$OctiFi_Charge_Id."/",
                                        [
                                            'timeout'     => 45,
                                            'headers' => $header,
                                            'body' =>  json_encode($params)
                                        ]
                                    );
                                    if ( is_wp_error( $res ) ) {
                                  
                                        $error_message = $res['response']['message'];
                                    } else {
                                     
                                        $result2 = json_decode( $res['body'], true);
                                        $this->log('trace_4');
                                        $this->log($options2);
                                        $this->log($result2);
                                        if ($result2['status_code'] == 200) {
                                            $charge_status = $result2['data']['state'];
                                            
                                            $order->delete_meta_data('OctiFi_Captured');
                                            $capture_status = 0;
                                            if ($charge_status == 'ChargeState.CAPTURED') {
                                                $capture_status = 1;
                                            }
                                            $order->add_meta_data('OctiFi_Captured', $capture_status);
                                            $order->save_meta_data();
                                            
                                            $order->update_status('processing', __('Payment successful with OctiFi(Authorized and Captured). Charge Status: '.$charge_status.'.', $this->domain));
                                            wp_redirect($this->get_return_url($order));
                                        } else {
                                            $error_message = $result2['message'];
                                        }
                                    }
                                } else {
                                    $charge_status = $result['data']['order_detail']['status'];
                                    $order->update_status('processing', __('Payment successful with OctiFi (Authorized). Charge Status: '.$charge_status.'.', $this->domain));
                                    wp_redirect($this->get_return_url($order));
                                }
                            } else {
                                $error_message = $result['message'];
                                $order->delete_meta_data('OctiFi_Charge_Id');
                                $order->delete_meta_data('OctiFi_Txn_Number');

                                if (isset($result['data']['charge_id'])) {
                                    $order->add_meta_data('OctiFi_Charge_Id', $result['data']['charge_id']);
                                }
                                if (isset($result['data']['order_payment_details']['data']['txn_number'])) {
                                    $order->add_meta_data('OctiFi_Txn_Number', $result['data']['order_payment_details']['data']['txn_number']);
                                }
                                $order->save_meta_data();
                            }
                        }
                    } else {
                        $error_message =  __('No Checkout Token from OctiFi', $this->domain);
                    }

                    if ($error_message) {
                        wc_add_notice(__('Payment error: ', 'woocommerce') . $error_message);
                        $order->update_status('failed', __('Payment Failed with OctiFi. Reason: '.$error_message, $this->domain));
                        $error_message = base64_encode($error_message);
                        wp_redirect($this->get_return_url($order).'&octifierr='.$error_message);
                    }

                } else {
                    $search = 'failed?data';
                    if (strpos($checkout, $search) !== false || $checkout == 'failed') {
                        if ($checkout == 'failed') {
                            $response['errorcode'] = sanitize_text_field( $_REQUEST['errorcode'] );
                            $response['merchant_order_id'] = sanitize_text_field( $_REQUEST['merchant_order_id'] );
                            $response['statuscode'] = sanitize_text_field( $_REQUEST['statuscode'] );
                        } else {
                            $data = str_replace($search, '', $checkout);
                            $jsonData =  base64_decode($data);
                            $response = json_decode($jsonData, true);
                        }
                        
                        $error_message = $response['errorcode'];
                        if (is_array($response['errorcode'])) {
                            $error_message = $response['errorcode'][0];
                        }

                        $order_id = $response['merchant_order_id'];
                        $order = new WC_Order($order_id);
                        $order->update_status('failed', __('Payment Failed with OctiFi. Reason: '.$error_message, $this->domain));

                        $order->add_meta_data('OctiFi_Payment_Status_Code', $response['statuscode']);
                        $order->save_meta_data();

                        $error_message = base64_encode($error_message);
                        wp_redirect($this->get_return_url($order).'&octifierr='.$error_message);
                    }
                }
            }
            exit;
        }

        /**
         * Process the payment and return the result.
         *
         * @param int $order_id
         * @return array
         */
        public function process_payment($order_id) {
            $order = wc_get_order($order_id);
            return array(
                'result' => 'success',
                'redirect' => $order->get_checkout_payment_url( true )
            );
        }
        
        public function get_site_logo()
        {
            $custom_logo_id = get_theme_mod( 'custom_logo' );
            $image = wp_get_attachment_image_src( $custom_logo_id , 'full' );
            return $image[0];
        }
        
        public function log($content) {
            $debug = OCTIFI_DEBUG;
            if ($debug == true) {
                $file = OCTIFI_PLUGIN_PATH.'debug.log';
                $fp = fopen($file, 'a+');
                fwrite($fp, "\n");
                fwrite($fp, date("Y-m-d H:i:s").": ");
                fwrite($fp, print_r($content, true));
                fclose($fp);
            }
        }
    }
}

add_filter('woocommerce_payment_gateways', 'octififunction_add_octifi_gateway_class');
function octififunction_add_octifi_gateway_class($methods) {
    $methods[] = 'WC_OctiFi';
    return $methods;
}

add_filter( 'woocommerce_available_payment_gateways', 'octififunction_enable_octifi_gateway' );
function octififunction_enable_octifi_gateway( $available_gateways ) {
    if ( is_admin() ) return $available_gateways;

    if ( isset( $available_gateways['octifi'] )) {
        $settings = get_option('woocommerce_octifi_settings');
        
        if(empty($settings['api_key'])) {
            unset( $available_gateways['octifi'] );
        }
        if(empty($settings['private_api_key'])) {
            unset( $available_gateways['octifi'] );
        }
    } 
    return $available_gateways;
}
add_action( 'woocommerce_checkout_order_review', 'octififunction_woocommrece_checkout_text');

function octififunction_woocommrece_checkout_text(){
    global $woocommerce;
    $amount2 = floatval( preg_replace( '#[^\d.]#', '', WC()->cart->total ) );
    $final_amount= $amount2/3;
    $final_amount=round($final_amount,2);
?>
<!-- final amount conversion input -->
	<input type="hidden" value="<?php echo $final_amount; ?>" id="final_amount" />
<!--Creates the popup body-->
<div class="modal-ocitifi">

	<div class="moda-ocitifi-dialog">
		<div class="modal-content-wrap">
			<div class="popup-overlay">
				<!--Creates the popup content-->
				<div class="popup-content">
					<a href="#" class="close-btn">X</a>
					<div class="top-head-image">
					    <center>
						<img src="<?php echo OCTIFI_PLUGIN_URL; ?>assets/images/logo.png" class="img-fluid" alt="logo"></center>
						<h5 class="head-title">Be the savvy customer and choose LatitudePay at checkout </h5>
					</div>
					<div class="cstm-row">
						<div class="cstm-col">
							<div class="checkout-card">
								<img src="<?php echo OCTIFI_PLUGIN_URL; ?>assets/images/Pay-only-1_3-today-icon.gif" class="img-fluid" alt="card-img">
								<h6>Pay only 1/3 today</h6>
								<p>We pay the store full, and you pay us in 3 instalment,  <b>0% interest with no hidden fees</b></p>
							</div>
						</div>
						
						<div class="cstm-col">
							<div class="checkout-card  both-debit">
								<img src="<?php echo OCTIFI_PLUGIN_URL; ?>assets/images/Usebothcreditn debitcard.gif" class="img-fluid" alt="card-img">
								<h6>Use both debit or credit card</h6>
								<p>No credit card? No problem! We accept any Singapore Banks issue debit cards.</p>
							</div>
						</div>
						
						<div class="cstm-col">
							<div class="checkout-card">
								<img src="<?php echo OCTIFI_PLUGIN_URL; ?>assets/images/Earncashbackicon.gif" class="img-fluid" alt="card-img">
								<h6>Earn 1.5% cashback </h6>
								<p>Have more cash to spare? Pay more upfront and earn additional 1.5% cashback from us!</p>
							</div>
						</div>
					</div>
					<div class="footer-title">
						<h5 class="head-title">Pay with your preferred payment methods</h5>
						<ul class="payment-img">
							<li><img src="<?php echo OCTIFI_PLUGIN_URL; ?>assets/images/visa.png"></li>
							<li><img src="<?php echo OCTIFI_PLUGIN_URL; ?>assets/images/mastercard.png"></li>
							<li class="american-img"><img src="<?php echo OCTIFI_PLUGIN_URL; ?>assets/images/American-express.png"></li>
						</ul>
						<div class="link-footer">
							<p>Terms and Condition Applies.<a href="<?php if($settings['select_the_country']=="1"){echo "https://octifi.com/paylater_terms/";}else{echo "https://my.latitudepay.com/paylater_terms/";} ?>" target="_blank" style="text-decoration: none;">See full T&c here >></a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<?php } add_action( 'woocommerce_review_order_before_shipping', 'octififunction_shipping'); 
function octififunction_shipping(){ 
     global $woocommerce;
    $amount2 = floatval( preg_replace( '#[^\d.]#', '', WC()->cart->total ) );
    $final_amount= $amount2/3;
    $final_amount1=round($final_amount,2);
?>
 <script type="text/javascript">
	  console.log("<?php echo $final_amount1; ?>");
		var value="<?php echo $final_amount1; ?>";
	 jQuery('#final_amount').val(value);
	 jQuery("#checkout-newpayment").text(value);
	jQuery(".shipping_method").on("click", function(){
	
	   console.log("<?php echo $final_amount1; ?>");
		var value1="<?php echo $final_amount1; ?>";
		jQuery('#final_amount').val(value1);
	 });
	 
    </script>
<?php }

//Add Custom Content Before 'Add To Cart' Button On Product Page
function octififunction_my_content( $content ) { 
    
    $settings = get_option('woocommerce_octifi_settings');

    ?>


<!--Creates the popup body-->
<div class="modal-ocitifi">
    <div class="moda-ocitifi-dialog">
        <div class="modal-content-wrap">
            <div class="popup-overlay">
                <!--Creates the popup content-->
                <div class="popup-content">
                    <a href="#" class="close-btn">X</a>
                    <div class="top-head-image">
                        <center>
                        <img src="<?php echo OCTIFI_PLUGIN_URL; ?>assets/images/logo.png" class="img-fluid" alt="logo"></center>
                        <h5 class="head-title">Be the savvy customer and choose LatitudePay at checkout </h5>
                    </div>
                    <div class="cstm-row">
                        <div class="cstm-col">
                            <div class="checkout-card">
                                <img src="<?php echo OCTIFI_PLUGIN_URL; ?>assets/images/Pay-only-1_3-today-icon.gif" class="img-fluid" alt="card-img">
                                <h6>Pay only 1/3 today</h6>
                                <p>We pay the store full, and you pay us in 3 instalment,  <b>0% interest with no hidden fees</b></p>
                            </div>
                        </div>
                        
                        <div class="cstm-col">
                            <div class="checkout-card  both-debit">
                                <img src="<?php echo OCTIFI_PLUGIN_URL; ?>assets/images/Usebothcreditn debitcard.gif" class="img-fluid" alt="card-img">
                                <h6>Use both debit or credit card</h6>
                                <p>No credit card? No problem! We accept any Singapore Banks issue debit cards.</p>
                            </div>
                        </div>
                        
                        <div class="cstm-col">
                            <div class="checkout-card">
                                <img src="<?php echo OCTIFI_PLUGIN_URL; ?>assets/images/Earncashbackicon.gif" class="img-fluid" alt="card-img">
                                <h6>Earn 1.5% cashback </h6>
                                <p>Have more cash to spare? Pay more upfront and earn additional 1.5% cashback from us!</p>
                            </div>
                        </div>
                    </div>
                    <div class="footer-title">
                        <h5 class="head-title">Pay with your preferred payment methods</h5>
                        <ul class="payment-img">
                            <li><img src="<?php echo OCTIFI_PLUGIN_URL; ?>assets/images/visa.png"></li>
                            <li><img src="<?php echo OCTIFI_PLUGIN_URL; ?>assets/images/mastercard.png"></li>
                            <li class="american-img"><img src="<?php echo OCTIFI_PLUGIN_URL; ?>assets/images/American-express.png"></li>
                        </ul>
                        <div class="link-footer">
                            <p>Terms and Condition Applies.<a href="<?php if($settings['select_the_country']=="1"){echo "https://octifi.com/paylater_terms/";}else{echo "https://my.latitudepay.com/paylater_terms/";} ?>" target="_blank" style="text-decoration: none;">See full T&c here >></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php 
$product = wc_get_product( get_the_ID() );
if( $product ){
  
    $thePrice = $product->get_price(); 
    $my_amount2 = floatval( preg_replace( '#[^\d.]#', '', $thePrice ) );
    $final_amount_product= $my_amount2/3;
    $final_amount_product=round($final_amount_product,2);
 

    $type_product=$product->get_type();
 
    if( $type_product == "simple" || $type_product == "grouped" || $type_product == "external" )
    {
        $thePrice = $product->get_price(); 
        $custom_value=get_option( 'my_field', '' );
        $admin_set=$custom_value; 
        if( $thePrice <= $admin_set ){
            
        }
        else{
            $my_amount2 = floatval( preg_replace( '#[^\d.]#', '', $thePrice ) );
            $final_amount_product= $my_amount2/3;
            $final_amount_product=round($final_amount_product,2);
            
        }

        
     
        $show_message = 0;
        if( isset( $settings['min_sum'] ) && $settings['min_sum'] != '' ){
            $min_sum = (float)$settings['min_sum'];
 
            if( (float)$thePrice > $min_sum ){
                $show_message = 1;
            }

        }else{
            $show_message = 1;
        }

        // hide_text settings processing
        if( $settings['hide_text'] == 'yes' || !$settings['hide_text'] ){
            $show_message = 0;
        }
        
    }
    elseif( $type_product == "variable" )
    {

    $formatted_price = (float)$product->get_variation_price('max'); 
  //  var_dump( $formatted_price );
    //$thePrice=number_format($formatted_price,0,' ','.'); 
   // var_dump( $thePrice );
            //$my_amount2 = floatval( preg_replace( '#[^\d.]#', '', $thePrice ) );
          //  var_dump( $my_amount2 );
            $final_amount_product= $formatted_price/3;
            $final_amount_product=round($final_amount_product,2);
  
    }
}

/**/
 

        $show_message = 0;
        if( isset( $settings['min_sum'] ) && $settings['min_sum'] != '' ){
            $min_sum = (float)$settings['min_sum'];
            if( (float)$formatted_price > $min_sum ){
                $show_message = 1;
            }

        }else{
            $show_message = 1;
        }

        // hide_text settings processing
        if( $settings['hide_text'] == 'yes' || !$settings['hide_text'] ){
            $show_message = 0;
        }
        if($settings['min_sum'] <= $product->get_price())
            {
                $msgdata="1";
            }
            else
            {
                $msgdata="0";
            }

 if ( is_product()  & $settings['enabled']=="yes" & $msgdata=="1" ){

     echo '<p class="checkout-text-octifi">or 3 payments of '.get_woocommerce_currency_symbol().'<span id="checkout-newpayment">'.$final_amount_product.'</span> with <img src="'.OCTIFI_PLUGIN_URL.'assets/images/logo.png" style="width:50px; margin: 0px auto;"></p><p id="OpenDialog">Learn more>></p>';
        //return $content;
    }
}
add_filter('woocommerce_before_add_to_cart_quantity', 'octififunction_my_content', 10, 2);



add_action( 'woocommerce_after_shop_loop_item', 'octififunction_custom_field_display_below_title', 2 );
function octififunction_custom_field_display_below_title(){

    $settings = get_option('woocommerce_octifi_settings');

$product = wc_get_product(get_the_ID());
$type_product=$product->get_type();


if( $type_product == "simple" || $type_product == "grouped" || $type_product == "external" )
{
    $thePrice = $product->get_price(); 
    $custom_value=get_option( 'my_field', '' );
    $admin_set=$custom_value; 
    if( $thePrice <= $admin_set ){
           
    }
    else{
        $my_amount2 = floatval( preg_replace( '#[^\d.]#', '', $thePrice ) );
        $final_amount_product= $my_amount2/3;
        $final_amount_product=round($final_amount_product,2);

        $show_message = 0;
        if( isset( $settings['min_sum'] ) && $settings['min_sum'] != '' ){
            $min_sum = (float)$settings['min_sum'];
            if( $thePrice > $min_sum ){
                $show_message = 1;
            }

        }else{
            $show_message = 1;
        }

     if( $settings['hide_text_homepage'] == 'yes' || !$settings['hide_text_homepage'] ){
                $show_message = 0;
            }
            else{
                 $show_message = 1;
            }
            if($settings['min_sum'] <= $product->get_price())
            {
                $msgdata="1";
            }
            else
            {
                $msgdata="0";
            }
         // echo"<pre>";print_r($msgdata);echo"<pre>";die();
        if( $show_message == 1 & $settings['enabled']=="yes" &  $msgdata=="1" ){
            /*echo '<p class="checkout-text-octifi">Pay only '.get_woocommerce_currency_symbol().'<span id="checkout-newpayment">'.$final_amount_product.'</span> today with <img src="'.OCTIFI_PLUGIN_URL.'assets/images/logo.png" style="width:50px; margin: 0px auto;"> instalments</p><p id="OpenDialog">Learn more>></p>';
*/    
echo '<p class="checkout-text-octifi">or 3 payments of '.get_woocommerce_currency_symbol().'<span id="checkout-newpayment">'.$final_amount_product.'</span> with <img src="'.OCTIFI_PLUGIN_URL.'assets/images/logo.png" style="width:50px; margin: 0px auto;"></p>';
}

        
    }

}
elseif( $type_product == "variable" )
{

$formatted_price = $product->get_variation_price('max'); 
$thePrice=number_format($formatted_price,0,' ','.'); 
$custom_value=get_option( 'my_field', '' );
$admin_set=$custom_value;
 if( $thePrice  <= $admin_set ){
           
    }
    else{
        //$my_amount2 = floatval( preg_replace( '#[^\d.]#', '', $thePrice ) );
        $my_amount2 = (float)( $formatted_price );
        $final_amount_product= $my_amount2/3;
        $final_amount_product=round($final_amount_product,2);
        

        $show_message = 0;
        if( isset( $settings['min_sum'] ) && $settings['min_sum'] != '' ){
            $min_sum = (float)$settings['min_sum'];
            if( $thePrice > $min_sum ){
                $show_message = 1;
            }

        }else{
            $show_message = 1;
        }

        // hide_text settings processing
        if( $settings['hide_text'] == 'yes' || !$settings['hide_text'] ){
            $show_message = 0;
        }

        if( $show_message == 1 ){
            echo '<p class="checkout-text-octifi">Pay only '.get_woocommerce_currency_symbol().'<span id="checkout-newpayment">'.$final_amount_product.'</span> today with <img src="'.OCTIFI_PLUGIN_URL.'assets/images/logo.png" style="width:50px; margin: 0px auto;" > instalments</p><p id="OpenDialog">Learn more>></p>';
        }
    }
}
}

add_filter( 'woocommerce_available_payment_gateways', 'octififunction_checkout_payment_check' );

function octififunction_checkout_payment_check( $available_payment_gateways ) {

global $woocommerce;
    
$cart = $woocommerce->cart;
if(isset($woocommerce->cart->total)){
$cart_total= $woocommerce->cart->total;
}else{
$cart_total="";
}
$custom_value=get_option( 'my_field', '' );
$admin_set=$custom_value; 
if( $cart_total <= $admin_set )
    {
        if ( isset( $available_payment_gateways['octifi'] ) ) 
        {
            unset( $available_payment_gateways['octifi'] );
        }
    }     
    return $available_payment_gateways;
}

add_filter('admin_init', 'octififunction_my_general_settings_register_fields');
function octififunction_my_general_settings_register_fields()
{
    register_setting('general', 'my_field', 'esc_attr');
    add_settings_field('my_field', '<label for="my_field">'.__('Octifi Value' , 'my_field' ).'</label>' , 'octififunction_my_general_settings_fields_html', 'general');
}
 
function octififunction_my_general_settings_fields_html()
{
    $value = get_option( 'my_field', '' );
    echo '<input type="text" id="my_field" name="my_field" value="' . $value . '" />';
}
function my_plugin_settings_link($links) { 
  $url=get_admin_url() . 'admin.php'.'?page=wc-settings&tab=checkout&section=octifi';
  //echo"<pre>"; print_r($url); echo"</pre>";die();
  $settings_link = '<a href='.$url.'>Settings</a>'; 
  array_unshift($links, $settings_link); 
  return $links; 
}
$plugin = plugin_basename(__FILE__); 
add_filter("plugin_action_links_$plugin", 'my_plugin_settings_link' );

function pw_load_scripts() {
    wp_register_script( 'octifi_custom_js', plugins_url('/assets/js/custom.js', __FILE__), [ 'jquery' ] ) ;           
    wp_enqueue_script( 'octifi_custom_js'  ) ;

}
add_action('admin_enqueue_scripts', 'pw_load_scripts');

function add_lpay_cusrrency_settings($settings) {
    // Search array for the id you want
    $symb = get_woocommerce_currency();
    global $wpdb;
    if($symb =='SGD'){
        $val = 1;
    }
    elseif($symb =='MYR'){
        $val = 2;
    }
    else{
        $val = 1;
    } 
    $qry = $wpdb->get_var("SELECT option_value FROM wp_options WHERE option_name = 'woocommerce_octifi_settings' ");
     $column = unserialize($qry);
     $column['select_the_country'] = $val;
     $str = serialize($column);

     $wpdb->query("UPDATE wp_options SET option_value = '".$str."' WHERE option_name = 'woocommerce_octifi_settings' ");

    $key              = array_search('woocommerce_currency', array_column($settings, 'id')) + 1;
    $custom_setting[] = array(
        'id'       => 'woocommerce_octifi_select_the_country',
        'default'  => '',
        'type'     => 'hidden',
    );

    // Merge with existing settings at the specified index
    $new_settings = array_merge(array_slice($settings, 0, $key), $custom_setting, array_slice($settings, $key));
    return $new_settings;
}
add_filter('woocommerce_general_settings', 'add_lpay_cusrrency_settings');
