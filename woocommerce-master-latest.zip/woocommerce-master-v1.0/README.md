# woocomerce
woocomerce plugin
=== OctiFi Payment System for WooCommerce ===
Contributors: OctiFi
Tags: OctiFi payments, woocommerce, payment gateway, installments
Requires at least: 4.0
Tested up to: 5.4.1
Stable tag: 1.0.0
Requires PHP: 5.5
License: MIT

Allows payments with OctiFi Payment on your WooCommerce website

== Installation ==

= Using The WordPress Dashboard =

1. Navigate to the 'Add New' in the plugins dashboard
2. Search for 'OctiFi Payment'
3. Click 'Install Now'
4. Activate the plugin on the Plugin dashboard

= Uploading in WordPress Dashboard =

1. Navigate to the 'Add New' in the plugins dashboard
2. Navigate to the 'Upload' area
3. Select `woocommerce-octifi.zip` from your computer
4. Click 'Install Now'
5. Activate the plugin in the Plugin dashboard

= Using FTP =

1. Download `woocommerce-octifi.zip`
2. Extract the `woocommerce-octifi` directory to your computer
3. Upload the `woocommerce-cryptapi` directory to the `/wp-content/plugins/` directory
4. Activate the plugin in the Plugin dashboard

== Changelog ==

= 1.0 =
* Initial release.

== Upgrade Notice ==
= 1.0.2 =
- Country code added to checkout web redirect

= 1.0.3 =
- Saving Checkout token in the order
