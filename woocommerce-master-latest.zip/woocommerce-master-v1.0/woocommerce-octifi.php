<?php
/*
  Plugin Name: OctiFi Payment
  Description: Allows payments by mobile phone with OctiFi. Contact info@octifi.com if any queries.
  Author: <a href="https://octifi.com/">OctiFi</a>   
  Version: 1.0.3
  
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

define('OCTIFI_PLUGIN_URL', plugin_dir_url(__FILE__));
define('OCTIFI_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('OCTIFI_DEBUG', false);

/**
 * Initiate OctiFi Payment once plugin is ready
 */
add_action('plugins_loaded', 'woocommerce_octifi_init');

function woocommerce_octifi_init() {

    class WC_OctiFi extends WC_Payment_Gateway {

        public $domain;

        /**
         * Constructor for the gateway.
         */
        public function __construct() {
            $this->domain = 'octifi';

            $this->id = 'octifi';
            $this->icon = OCTIFI_PLUGIN_URL . 'assets/images/logo.png';
            $this->has_fields = false;
            $this->method_title = __('OctiFi Payment', $this->domain);
            $this->method_description = __('Allows payments by mobile phone with OctiFi. Contact info@octifi.com if any queries.', $this->domain);
            
            // Define user set variables
            $this->title = $this->get_option('title');
            $this->description = $this->get_option('description');
            $this->api_key = $this->get_option('api_key');
            $this->private_api_key = $this->get_option('private_api_key');

	    // Load the settings.
            $this->init_form_fields();
            $this->init_settings();

            // Actions
            add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
            add_action('woocommerce_receipt_' . $this->id, array( $this, 'receipt_page' ));
            add_action('woocommerce_thankyou_' . $this->id, array($this, 'thankyou_page'));
            add_action('woocommerce_api_'. strtolower("WC_OctiFi"), array( $this, 'check_ipn_response' ) );
            
        }

        /**
         * Initialize Gateway Settings Form Fields.
         */
        public function init_form_fields() {
    
	    $field_arr = array(
                'enabled' => array(
                    'title' => __('Enable/Disable', $this->domain),
                    'type' => 'checkbox',
                    'label' => __('Enable OctiFi Payment', $this->domain),
                    'default' => 'yes'
                ),
                'title' => array(
                    'title' => __('Title', $this->domain),
                    'type' => 'text',
                    'description' => __('This controls the title which the user sees during checkout.', $this->domain),
                    'default' => $this->method_title,
                    'desc_tip' => true,
                ),
                'description' => array(
                    'title' => __('Instructions', $this->domain),
                    'type' => 'textarea',
                    'description' => __('Instructions that that the customer will see on your checkout.', $this->domain),
                    'desc_tip' => true,
                    'default' => __('Pay in 3 installments via OctiFi Payment Gateway Securely', $this->domain),
                ),
                'api_key' => array(
                    'title' => __('Public API Key', $this->domain),
                    'type' => 'text',
                ),
                'private_api_key' => array(
                    'title' => __('Private API Key', $this->domain),
                    'type' => 'text',
                ),
            );

            $this->form_fields = $field_arr;
        }

        /**
         * Process Gateway Settings Form Fields.
         */
	public function process_admin_options() {
            $this->init_settings();

            $post_data = $this->get_post_data();
            if (empty($post_data['woocommerce_octifi_api_key'])) {
                WC_Admin_Settings::add_error(__('Please enter OctiFi Public API Key', $this->domain));
            } else if (empty($post_data['woocommerce_octifi_private_api_key'])) {
                WC_Admin_Settings::add_error(__('Please enter OctiFi Private API Key', $this->domain));
            } else {
                foreach ( $this->get_form_fields() as $key => $field ) {
                    $setting_value = $this->get_field_value( $key, $field, $post_data );
                    $this->settings[ $key ] = $setting_value;
                }
                return update_option( $this->get_option_key(), apply_filters( 'woocommerce_settings_api_sanitized_fields_' . $this->id, $this->settings ) );
            }
	}
        
        /**
        * Receipt page
        *
        * @param  int $order_id Order ID.
        */
        public function receipt_page( $order_id ) {
            global $woocommerce;
            
            $order = wc_get_order($order_id);
            $order_data = $order->get_data();
            
            $product_name = '';
            foreach ($order->get_items() as  $item) {
                $product_name .= $item->get_name().';'; 
            }
            $params['product_name'] = $product_name;
            
            include_once OCTIFI_PLUGIN_PATH.'templates/redirect.php';
        }

        /**
         * Output for the order received page.
         */
        public function thankyou_page($order_id) 
        {
            global $woocommerce;
            
            $order = new WC_Order($order_id);
            $status = $order->get_status();
            if ($status == 'pending') {
                $style = "width: 100%;  margin-bottom: 1rem; background: #00ccb8; padding: 20px; color: #fff; font-size: 22px;";
            ?>
                <div class="payment-panel">
                    <div style="<?php echo $style?>">
                    <?php echo __('Your payment status is pending, we will update the status as soon as we receive notification from OctiFi Payment System.', $this->domain) ?>
                    </div>
                </div>
            <?php
            } else if ($status == 'completed') {
                $style = "width: 100%;  margin-bottom: 1rem; background: green; padding: 20px; color: #fff; font-size: 22px;";
                $woocommerce->cart->empty_cart();
            ?>
                <div class="payment-panel">
                    <div style="<?php echo $style?>">
                    <?php echo __('Your payment is successful with OctiFi Payment System.', $this->domain) ?>
                    </div>
                </div>
            <?php    
            } else if ($status == 'failed') {
                $style = "width: 100%;  margin-bottom: 1rem; background: indianred; padding: 20px; color: #fff; font-size: 22px;";
                $error_message = '';
                if (isset($_GET['octifierr'])) {
                    $error_message = base64_decode($_GET['octifierr']);
                    $woocommerce->cart->empty_cart();
                }
            ?>
                 <div class="payment-panel">
                    <div style="<?php echo $style?>">
                    <?php echo __('Your payment is failed with OctiFi System. ', $this->domain) ?>
                    <?php if (!empty($error_message)) {?>
                        <?php echo $error_message ?>
                    <?php }?>
                    </div>
                </div>
            <?php
            } else if ($status == 'cancelled') {
                $style = "width: 100%;  margin-bottom: 1rem; background: indianred; padding: 20px; color: #fff; font-size: 22px;";
            ?>
                 <div class="payment-panel">
                    <div style="<?php echo $style?>">
                    <?php echo __('Your order is cancelled.', $this->domain) ?>
                    </div>
                </div>
            <?php
            }
        }
        
        public function check_ipn_response() {
            global $woocommerce;
            $checkout = $_REQUEST['checkout'];
            
            $search = 'success?data';
            if (strpos($checkout, $search) !== false) {
                $data = str_replace($search, '', $checkout);
                $jsonData =  base64_decode($data);
                $response = json_decode($jsonData, true);
                
                $error_message = '';
                
                $order_id = $response['merchant_order_id'];
                $order = new WC_Order($order_id);
                if ($response['statuscode'] == 200) {
                    $checkout_token = $response['checkout_token'];
                    
                    $order->delete_meta_data('OctiFi_Checkout_Token');
                    $order->add_meta_data('OctiFi_Checkout_Token', $checkout_token);
                    $order->save_meta_data();
                    
                    $header = array(
                        "accept: application/json",
                        "Content-Type: application/json",
                        "Authorization: Api-Key ".$this->private_api_key
                    );

                    $params = array(
                        "bill_total_amount" => $order->get_total(),
                        "bill_currency" => $order->get_currency(),
                        "bill_tax_amount" => $order->get_total_tax(), 
                        "is_capture" => true
                    );
  
                    $options = array(
                        CURLOPT_URL => "https://k2.octifi.com/api/v1/charge/create/".$checkout_token."/", 
                        CURLOPT_RETURNTRANSFER => true, 
                        CURLOPT_HEADER => false, 
                        CURLOPT_SSL_VERIFYPEER => false, 
                        CURLOPT_POST => true, 
                        CURLOPT_POSTFIELDS => json_encode($params), 
                        CURLOPT_HTTPHEADER => $header
                    );
                    
                    $ch = curl_init();
                    curl_setopt_array($ch, $options);
                    $response2 = curl_exec($ch);
                    
                    
                    if (!$response2) {
                        $error_message = curl_error($ch);
                        curl_close($ch);
                    } else {
                        curl_close($ch);
                        $result = json_decode($response2, true);
                        $this->log($options);
                        $this->log($result);
                        if ($result['status_code'] == 200) {
                            $order->delete_meta_data('OctiFi_Charge_Id');
                            $order->delete_meta_data('OctiFi_Txn_Number');
                            $order->add_meta_data('OctiFi_Charge_Id', $result['data']['charge_id']);
                            $order->add_meta_data('OctiFi_Txn_Number', $result['data']['order_payment_details']['data']['txn_number']);
                            $order->save_meta_data();

                            $params = array(
                                "charge_id" => $result['data']['charge_id']
                            );

                            $options2 = array(
                                CURLOPT_URL => "https://k2.octifi.com/api/v1/charge/capture/", 
                                CURLOPT_RETURNTRANSFER => true, 
                                CURLOPT_HEADER => false, 
                                CURLOPT_SSL_VERIFYPEER => false, 
                                CURLOPT_POST => true, 
                                CURLOPT_POSTFIELDS => json_encode($params), 
                                CURLOPT_HTTPHEADER => $header
                            );

                            $ch2 = curl_init();
                            curl_setopt_array($ch2, $options2);
                            $response3 = curl_exec($ch2);

                            if (!$response3) {
                                $error_message = curl_error($ch2);
                                curl_close($ch2);
                            } else {
                                curl_close($ch2);
                                $result2 = json_decode($response3, true);
                                $this->log($options2);
                                $this->log($result2);
                                if ($result2['status_code'] == 200) {
                                    $charge_status = $result2['message']['data']['ChargeStatus'];
                                    $order->update_status('completed', __('Payment successful with OctiFi. Charge Status: '.$charge_status.'.', $this->domain));
                                    wp_redirect($this->get_return_url($order));
                                } else {
                                    $error_message = $result2['message'];
                                }
                            }
                        } else {
                            $error_message = $result['message'];
                            $order->delete_meta_data('OctiFi_Charge_Id');
                            $order->delete_meta_data('OctiFi_Txn_Number');

                            if (isset($result['data']['charge_id'])) {
                                $order->add_meta_data('OctiFi_Charge_Id', $result['data']['charge_id']);
                            }
                            if (isset($result['data']['order_payment_details']['data']['txn_number'])) {
                                $order->add_meta_data('OctiFi_Txn_Number', $result['data']['order_payment_details']['data']['txn_number']);
                            }
                            $order->save_meta_data();
                        }
                    }
                } else {
                    $error_message =  __('No Checkout Token from OctiFi', $this->domain);
                }
                
                if ($error_message) {
                    wc_add_notice(__('Payment error: ', 'woocommerce') . $error_message);
                    $order->update_status('failed', __('Payment Failed with OctiFi. Reason: '.$error_message, $this->domain));
                    wp_redirect($this->get_return_url($order).'&octifierr='.$error_message);
                }
                
            } else {
                $search = 'failed?data';
                if (strpos($checkout, $search) !== false) {
                    $data = str_replace($search, '', $checkout);
                    $jsonData =  base64_decode($data);
                    $response = json_decode($jsonData, true);
                    
                    $order_id = $response['merchant_order_id'];
                    $order = new WC_Order($order_id);
                    $order->update_status('failed', __('Payment Failed with OctiFi. Reason: '.$response['errorcode'][0], $this->domain));
                    
                    $order->add_meta_data('OctiFi_Payment_Status_Code', $response['statuscode']);
                    $order->save_meta_data();
  
                    $error_message = base64_encode($response['errorcode'][0]);
                    wp_redirect($this->get_return_url($order).'&octifierr='.$error_message);
                }
            }
            exit;
        }

        /**
         * Process the payment and return the result.
         *
         * @param int $order_id
         * @return array
         */
        public function process_payment($order_id) {
            $order = wc_get_order($order_id);
            return array(
                'result' => 'success',
                'redirect' => $order->get_checkout_payment_url( true )
            );
        }
        
        public function get_site_logo()
        {
            $custom_logo_id = get_theme_mod( 'custom_logo' );
            $image = wp_get_attachment_image_src( $custom_logo_id , 'full' );
            return $image[0];
        }
        
        public function log($content) {
            $debug = OCTIFI_DEBUG;
            if ($debug == true) {
                $file = OCTIFI_PLUGIN_PATH.'debug.log';
                $fp = fopen($file, 'a+');
                fwrite($fp, "\n");
                fwrite($fp, date("Y-m-d H:i:s").": ");
                fwrite($fp, print_r($content, true));
                fclose($fp);
            }
        }
    }
}

add_filter('woocommerce_payment_gateways', 'add_octifi_gateway_class');
function add_octifi_gateway_class($methods) {
    $methods[] = 'WC_OctiFi';
    return $methods;
}

add_filter( 'woocommerce_available_payment_gateways', 'enable_octifi_gateway' );
function enable_octifi_gateway( $available_gateways ) {
    if ( is_admin() ) return $available_gateways;

    if ( isset( $available_gateways['octifi'] )) {
        $settings = get_option('woocommerce_octifi_settings');
        
        if(empty($settings['api_key'])) {
            unset( $available_gateways['octifi'] );
        }
        if(empty($settings['private_api_key'])) {
            unset( $available_gateways['octifi'] );
        }
    } 
    return $available_gateways;
}

