<p><?php echo __('Please wait, we are redirecting to the payment gateway...', $this->domain);?></p>
<div id="octif-loader"><img src="<?php echo OCTIFI_PLUGIN_URL ?>assets/images/loader.gif"></div>
<script src="<?php echo getOctifiEnv('OCTIFI_SCRIPT_SRC')?>"></script>
<script>
    jQuery(document).ready(function () {
        jQuery('.order_details').hide();
        var _octifi_config = {
            modal: false,
            public_api_key: '<?php echo $this->api_key?>',
            merchant_logo: "<?php echo $this->get_site_logo()?>",
            redirect_confirmation_url_action: "GET",
            redirect_callbacks: {
                onSuccess: "<?php echo site_url().'/?wc-api=wc_octifi&checkout=success'?>",
                onFail: "<?php echo site_url().'/?wc-api=wc_octifi&checkout=failed'?>",
            }
        };
        octifi.initialize(_octifi_config);

        octifi.checkout = {
            checkout: {
                merchant: {
                    name: "<?php echo addslashes(get_bloginfo( 'name' ))?>" //required
                },
                bill: {
                    display_name: "<?php echo addslashes($product_name)?>", //required
                    tax_amount: <?php echo $order->get_total_tax()?>, //required
                    total_amount: <?php echo $order->get_total()?>, //required
                    currency: "<?php echo $order_data['currency']?>",  //required
                    merchant_order_id: <?php echo $order->get_id()?>, //required
                },
                customer: {
                    phone_number: "<?php echo $order_data['billing']['phone']?>",
                    mobile_number: "<?php echo $order_data['billing']['phone']?>",
                    email: "<?php echo $order_data['billing']['email']?>",
                    country_code: "<?php echo $order_data['billing']['country']?>"
                },
                details: {
                    shipping: {
                        name: {
                            first: "<?php echo addslashes($order_data['shipping']['first_name'])?>",
                            last: "<?php echo addslashes($order_data['shipping']['last_name'])?>"
                        },
                        address: {
                            line1: "<?php echo addslashes($order_data['shipping']['address_1'])?>",
                            line2: "<?php echo addslashes($order_data['shipping']['address_2'])?>",
                            city: "<?php echo addslashes($order_data['shipping']['city'])?>",
                            state: "<?php echo addslashes($order_data['shipping']['state'])?>",
                            zipcode: "<?php echo $order_data['shipping']['postcode']?>",
                            country: "<?php echo $order_data['shipping']['country']?>"
                        },
                        Shipping_amount: <?php echo $order->get_shipping_total()?>,
                    },
                    billing: {
                        name: {
                            first: "<?php echo addslashes($order_data['billing']['first_name'])?>",
                            last: "<?php echo addslashes($order_data['billing']['last_name'])?>"
                        },
                        address: {
                            line1: "<?php echo addslashes($order_data['billing']['address_1'])?>",
                            line2: "<?php echo addslashes($order_data['billing']['address_2'])?>",
                            city: "<?php echo addslashes($order_data['billing']['city'])?>",
                            state: "<?php echo addslashes($order_data['billing']['state'])?>",
                            zipcode: "<?php echo $order_data['billing']['postcode']?>",
                            country: "<?php echo $order_data['billing']['country']?>"
                        },
                        phone_number: "<?php echo $order_data['billing']['phone']?>",
                        email: "<?php echo $order_data['billing']['email']?>"
                    },
                    product: [
                        <?php 
                        foreach ($order->get_items() as  $item) {
                            $product = $item->get_product();
                            
                            $product_id = $item->get_product_id();
                            $image_url = wp_get_attachment_image_src( get_post_thumbnail_id( $product_id ), 'single-post-thumbnail' );
                        ?>
                            {
                            display_name: "<?php echo addslashes($item->get_name())?>",
                            sku: "<?php echo $product->get_sku()?>",
                            unit_price: <?php echo $product->get_price()?>,
                            qty: <?php echo $item->get_quantity()?>,
                            item_image_url: "",
                            item_url: "<?php echo get_permalink( $product_id )?>",
                            },
                        <?php }?>
                    ],
                    <?php if ($order->get_discount_total() > 0) {?>
                    discounts: {
                        DISCOUNT: {
                            discount_amount: <?php echo $order->get_discount_total()?>,
                            discount_display_name: "Total Discount"
                        }
                    },
                    <?php }?>
                    <?php if ($order->get_shipping_method() != '') {?>
                    metadata: {
                        shipping_type: "<?php echo addslashes($order->get_shipping_method())?>"
                    },
                    <?php }?>
                },
            }
        }
        
        octifi.open(octifi.checkout);
    });
</script>