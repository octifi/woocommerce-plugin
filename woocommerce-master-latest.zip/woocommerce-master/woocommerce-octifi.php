<?php
/*
  Plugin Name: OctiFi Payment
  Description: Allows payments by mobile phone with OctiFi. Contact info@octifi.com if any queries.
  Author: <a href="https://octifi.com/">OctiFi</a>   
  Version: 2.0.5
  
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

define('OCTIFI_PLUGIN_URL', plugin_dir_url(__FILE__));
define('OCTIFI_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('OCTIFI_DEBUG', false);

include_once OCTIFI_PLUGIN_PATH.'vendor/octifienv/loader.php';

/**
 * Initiate OctiFi Payment once plugin is ready
 */
add_action('plugins_loaded', 'woocommerce_octifi_init');
function woocommerce_octifi_init() {

    class WC_OctiFi extends WC_Payment_Gateway {

        public $domain;

        /**
         * Constructor for the gateway.
         */
        public function __construct() {
            $this->domain = 'octifi';

            $this->id = 'octifi';
            $this->icon = OCTIFI_PLUGIN_URL . 'assets/images/logo.png';
            $this->has_fields = false;
            $this->method_title = __('OctiFi Payment', $this->domain);
            $this->method_description = __('Allows payments by mobile phone with OctiFi. Contact info@octifi.com if any queries.', $this->domain);
            
            // Define user set variables
            $this->title = $this->get_option('title');
            $this->description = $this->get_option('description');
            $this->api_key = $this->get_option('api_key');
            $this->private_api_key = $this->get_option('private_api_key');
            $this->payment_type = $this->get_option('payment_type');
            $this->payment_action = $this->get_option('payment_action');

	    // Load the settings.
            $this->init_form_fields();
            $this->init_settings();

            // Actions
            add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
            add_action('woocommerce_receipt_' . $this->id, array( $this, 'receipt_page' ));
            add_action('woocommerce_thankyou_' . $this->id, array($this, 'thankyou_page'));
            add_action('woocommerce_api_'. strtolower("WC_OctiFi"), array( $this, 'check_ipn_response' ) );
            add_action( 'woocommerce_order_status_completed', array( $this, 'order_completed'), 10, 1);
            add_action( 'woocommerce_admin_order_data_after_order_details', array( $this, 'admin_order_details'), 10, 3 );
        }

        /**
         * Initialize Gateway Settings Form Fields.
         */
        public function init_form_fields() {
	    $field_arr = array(
                'enabled' => array(
                    'title' => __('Enable/Disable', $this->domain),
                    'type' => 'checkbox',
                    'label' => __('Enable OctiFi Payment', $this->domain),
                    'default' => 'yes'
                ),
                'title' => array(
                    'title' => __('Title', $this->domain),
                    'type' => 'text',
                    'description' => __('This controls the title which the user sees during checkout.', $this->domain),
                    'default' => $this->method_title,
                    'desc_tip' => true,
                ),
                'description' => array(
                    'title' => __('Instructions', $this->domain),
                    'type' => 'textarea',
                    'description' => __('Instructions that that the customer will see on your checkout.', $this->domain),
                    'desc_tip' => true,
                    'default' => __('Pay in 3 installments via OctiFi Payment Gateway Securely', $this->domain),
                ),
                'api_key' => array(
                    'title' => __('Public API Key', $this->domain),
                    'type' => 'text',
                ),
                'private_api_key' => array(
                    'title' => __('Private API Key', $this->domain),
                    'type' => 'text',
                ),
                'payment_type' => array(
                    'title' => __('Choose Payment Type', $this->domain),
                    'id' => 'payment_type',
                    'type' => 'payment_type',
                    'default' => 'redirect',
                    'options' => $this->getPaymentTypes()
                ),
                'payment_action' => array(
                    'title' => __('Payment Action', $this->domain),
                    'type' => 'select',
                    'default' => 'capture',
                    'options' => $this->getPaymentActions()
                ),
            );

            $this->form_fields = $field_arr;
        }
        
        public function getPaymentTypes() {
            $types = [
                'redirect' => __('Redirect', $this->domain),
                'hosted' => __('Modal Popup', $this->domain),
            ];
            return $types;
        }
        
        public function getPaymentActions() {
            return [
                'authorise' => __('Authorization', $this->domain),
                'capture' => __('Authorise & Capture', $this->domain),
            ];
        }
        
        public function generate_payment_type_html( $key, $value ) { 
            $payment_type = $this->settings['payment_type'];
            if (empty($payment_type)) {
                $payment_type = $value['default'];
            }
            $html = '<tr valign="top">
                    <th scope="row" class="titledesc">
                        <label for="woocommerce_octifi_'.$key.'">'. $value['title'].'</label>
                    </th>
                    <td class="forminp forminp-'.$key.'">
                    <fieldset>';
                    foreach($value['options'] as $type => $option) {    
                        $html .= '<label for="woocommerce_octifi_'.$key.'_'.$type.'">'
                                . '<input '
                                . 'type="radio" '
                                . 'name="woocommerce_octifi_'.$key.'" '
                                . 'id="woocommerce_octifi_'.$key.'_'.$type.'" '
                                . 'value="'.$type.'" '
                                . (($payment_type == $type) ? 'checked="checked"':'').'> '.$option.'</label>&nbsp;&nbsp;';
                    }
                    $html .= '</fieldset>
                    </td>
                </tr>';
            return $html;
        }

        /**
         * Process Gateway Settings Form Fields.
         */
	public function process_admin_options() {
            $this->init_settings();

            $post_data = $this->get_post_data();
            if (empty($post_data['woocommerce_octifi_api_key'])) {
                WC_Admin_Settings::add_error(__('Please enter OctiFi Public API Key', $this->domain));
            } else if (empty($post_data['woocommerce_octifi_private_api_key'])) {
                WC_Admin_Settings::add_error(__('Please enter OctiFi Private API Key', $this->domain));
            } else {
                foreach ( $this->get_form_fields() as $key => $field ) {
                    $setting_value = $this->get_field_value( $key, $field, $post_data );
                    $this->settings[ $key ] = $setting_value;
                }
                return update_option( $this->get_option_key(), apply_filters( 'woocommerce_settings_api_sanitized_fields_' . $this->id, $this->settings ) );
            }
	}
        
        /**
        * Receipt page
        *
        * @param  int $order_id Order ID.
        */
        public function receipt_page( $order_id ) {
            global $woocommerce;
            
            $order = wc_get_order($order_id);
            $order_data = $order->get_data();
            
            $order->delete_meta_data('OctiFi_Payment_Action');
            $order->add_meta_data('OctiFi_Payment_Action', $this->payment_action);
            $order->save_meta_data();
            
            $product_name = '';
            foreach ($order->get_items() as  $item) {
                $product_name .= $item->get_name().';'; 
            }
            $params['product_name'] = $product_name;
            
            if ($this->payment_type == 'redirect') {
                include_once OCTIFI_PLUGIN_PATH.'templates/redirect.php';
            } else {
                include_once OCTIFI_PLUGIN_PATH.'templates/modal.php';
            }
        }

        /**
         * Output for the order received page.
         */
        public function thankyou_page($order_id) 
        {
            global $woocommerce;
            
            $order = new WC_Order($order_id);
            $status = $order->get_status();
            if ($status == 'pending') {
                $style = "width: 100%;  margin-bottom: 1rem; background: #00ccb8; padding: 20px; color: #fff; font-size: 22px;";
            ?>
                <div class="payment-panel">
                    <div style="<?php echo $style?>">
                    <?php echo __('Your payment status is pending, we will update the status as soon as we receive notification from OctiFi Payment System.', $this->domain) ?>
                    </div>
                </div>
            <?php
            } else if ($status == 'processing') {
                $style = "width: 100%;  margin-bottom: 1rem; background: green; padding: 20px; color: #fff; font-size: 22px;";
                $woocommerce->cart->empty_cart();
            ?>
                <div class="payment-panel">
                    <div style="<?php echo $style?>">
                    <?php echo __('Your payment is successful with OctiFi Payment System.', $this->domain) ?>
                    </div>
                </div>
            <?php    
            } else if ($status == 'failed') {
                $style = "width: 100%;  margin-bottom: 1rem; background: indianred; padding: 20px; color: #fff; font-size: 22px;";
                $error_message = '';
                if (isset($_GET['octifierr'])) {
                    $error_message = base64_decode($_GET['octifierr']);
                    $woocommerce->cart->empty_cart();
                }
            ?>
                 <div class="payment-panel">
                    <div style="<?php echo $style?>">
                    <?php echo __('Your payment is failed with OctiFi System. ', $this->domain) ?>
                    <?php if (!empty($error_message)) {?>
                        <?php echo $error_message ?>
                    <?php }?>
                    </div>
                </div>
            <?php
            } else if ($status == 'cancelled') {
                $style = "width: 100%;  margin-bottom: 1rem; background: indianred; padding: 20px; color: #fff; font-size: 22px;";
            ?>
                 <div class="payment-panel">
                    <div style="<?php echo $style?>">
                    <?php echo __('Your order is cancelled.', $this->domain) ?>
                    </div>
                </div>
            <?php
            }
        }
        
        public function admin_order_details( $order ){
            if ($order->get_payment_method() == $this->id) {
                $order_id = $order->get_id();
                
                $status_message = '';
                $status = '';
                
                if (isset($_GET['octifi_capture'])) {
                    $charge_id = get_post_meta( $order_id, 'OctiFi_Charge_Id', true );
                    if (!empty($charge_id)) {
                        $header = array(
                            "accept: application/json",
                            "Content-Type: application/json",
                            "Authorization: Api-Key ".$this->private_api_key
                        );
                        
                        $params = array(
                            "charge_id" => $charge_id
                        );

                        $options2 = array(
                            CURLOPT_URL => getOctifiEnv('OCTIFI_CHARGE_URL'), 
                            CURLOPT_RETURNTRANSFER => true, 
                            CURLOPT_HEADER => false, 
                            CURLOPT_SSL_VERIFYPEER => false, 
                            CURLOPT_POST => true, 
                            CURLOPT_POSTFIELDS => json_encode($params), 
                            CURLOPT_HTTPHEADER => $header
                        );

                        $ch2 = curl_init();
                        curl_setopt_array($ch2, $options2);
                        $response3 = curl_exec($ch2);

                        if (!$response3) {
                            $message = curl_error($ch2);
                            $status_message = $message;
                            curl_close($ch2);
                            $status = 'error';
                        } else {
                            curl_close($ch2);
                            $result2 = json_decode($response3, true);
                            $this->log($options2);
                            $this->log($result2);
                            if ($result2['status_code'] == 200) {
                                $message = $result2['message'];
                                if($message == 'This charge has already been captured') {
                                    $status_message = $message;
                                    $status = 'error';
                                } else {
                                    $charge_status = $result2['data']['ChargeStatus'];
                                    $message = __('Payment successful with OctiFi(Captured). Charge Status: '.$charge_status.'.', $this->domain);
                                    $status_message = __('Payment Captured Successfully.', $this->domain);
                                    $status = 'success';

                                    $order->delete_meta_data('OctiFi_Captured');
                                    $capture_status = 1;
                                    $order->add_meta_data('OctiFi_Captured', $capture_status);
                                    $order->save_meta_data();
                                }
                                            
                            } else {
                                $message = $result2['message'];
                                $status_message = $message;
                            }
                        }
                        $order->add_order_note( $message );
                    } else {
                        $status_message = __('Charge ID not found. ', $this->domain);
                        $status = 'error';
                    }
                } 
                
                $capture_url = get_edit_post_link($order_id).'&octifi_capture=1';
                
                $captured = (int)get_post_meta( $order_id, 'OctiFi_Captured', true );
                $charge_id = get_post_meta( $order_id, 'OctiFi_Charge_Id', true );
                $payment_action = get_post_meta( $order_id, 'OctiFi_Payment_Action', true );
                
                $style = "display: inline-block;margin-top: 20px;width: 100%;max-width: 100%;overflow: hidden;border-radius: 2px; text-align:center;";

                if (!empty($status_message)) {
                    $status_style = 'display: inline-block;margin-top: 30px;width: 100%;max-width: 100%;overflow: hidden; font-weight:600;';
                    if ($status == 'error') {
                        $status_style .= 'color: red;';
                    } else if ($status == 'success') {
                        $status_style .= 'color: green;';
                    }
                    echo '<div style="'.$status_style.'">'.$status_message.'</div>';
                }
                
                if ($captured == 1) {
                    $style .= 'border:3px solid green;';
            ?>
                <div style="<?php echo $style ?>">
                    <div style="padding: 10px; font-size: 16px; color: green">
                    <?php echo __('Octifi Payment Captured.', $this->domain) ?>
                    </div>
                </div>
            <?php
                } else {
                    $style .= 'border:2px solid orange;';
            ?>
                <div style="<?php echo $style ?>">
                    <div style="padding: 10px; ">
                        <a href="<?php echo $capture_url?>" class="button button-primary"><?php echo __('Capture Octifi Payment', $this->domain) ?></a>
                    </div>
                </div>
            <?php         
                }
            }
        }
        
        public function order_completed($order_id) {
            global $woocommerce;
            $payment_action = get_post_meta( $order_id, 'OctiFi_Payment_Action', true );
            if ($payment_action == 'authorise') {
                $order = new WC_Order($order_id);
                if ($order->get_payment_method() == $this->id) {
                    $charge_id = get_post_meta( $order->id, 'OctiFi_Charge_Id', true );
                    if (!empty($charge_id)) {
                        $header = array(
                            "accept: application/json",
                            "Content-Type: application/json",
                            "Authorization: Api-Key ".$this->private_api_key
                        );
                        
                        $params = array(
                            "charge_id" => $charge_id
                        );

                        $options2 = array(
                            CURLOPT_URL => getOctifiEnv('OCTIFI_CHARGE_URL'), 
                            CURLOPT_RETURNTRANSFER => true, 
                            CURLOPT_HEADER => false, 
                            CURLOPT_SSL_VERIFYPEER => false, 
                            CURLOPT_POST => true, 
                            CURLOPT_POSTFIELDS => json_encode($params), 
                            CURLOPT_HTTPHEADER => $header
                        );

                        $ch2 = curl_init();
                        curl_setopt_array($ch2, $options2);
                        $response3 = curl_exec($ch2);

                        if (!$response3) {
                            $message = curl_error($ch2);
                            curl_close($ch2);
                        } else {
                            curl_close($ch2);
                            $result2 = json_decode($response3, true);
                            $this->log($options2);
                            $this->log($result2);
                            if ($result2['status_code'] == 200) {
                                $charge_status = $result2['data']['ChargeStatus'];
                                $message = __('Payment successful with OctiFi(Captured). Charge Status: '.$charge_status.'.', $this->domain);
                                $capture_status = 1;
                                $order->add_meta_data('OctiFi_Captured', $capture_status);
                                $order->save_meta_data();
                            } else {
                                $message = $result2['message'];
                            }
                        }
                        $order->add_order_note( $message );
                    }
                }
            }
            
        }
        
        public function check_ipn_response() {
            global $woocommerce;

            if(isset($_REQUEST['checkout'])) {
                $checkout = $_REQUEST['checkout'];

                $search = 'success?data';
                if (strpos($checkout, $search) !== false || $checkout == 'success') {
                    if ($checkout == 'success') {
                        $response['checkout_token'] = $_REQUEST['checkout_token'];
                        $response['merchant_order_id'] = $_REQUEST['merchant_order_id'];
                        $response['statuscode'] = $_REQUEST['statuscode'];
                    } else {
                        $data = str_replace($search, '', $checkout);
                        $jsonData =  base64_decode($data);
                        $response = json_decode($jsonData, true);
                    }

                    $error_message = '';

                    $order_id = $response['merchant_order_id'];
                    $order = new WC_Order($order_id);
                    if ($response['statuscode'] == 200) {

                        $checkout_token = $response['checkout_token'];

                        $order->delete_meta_data('OctiFi_Checkout_Token');
                        $order->add_meta_data('OctiFi_Checkout_Token', $checkout_token);
                        $order->save_meta_data();
   
                        $header = array(
                            "accept: application/json",
                            "Content-Type: application/json",
                            "Authorization: Api-Key ".$this->private_api_key
                        );
                        
                        $is_capture = false;
                        if ($this->payment_action == 'capture') {
                            $is_capture = true;
                        }

                        $params = array(
                            "bill_total_amount" => $order->get_total(),
                            "bill_currency" => $order->get_currency(),
                            "bill_tax_amount" => $order->get_total_tax(), 
                            "is_capture" => $is_capture
                        );

                        $options = array(
                            CURLOPT_URL => getOctifiEnv('OCTIFI_CREATE_URL').$checkout_token."/", 
                            CURLOPT_RETURNTRANSFER => true, 
                            CURLOPT_HEADER => false, 
                            CURLOPT_SSL_VERIFYPEER => false, 
                            CURLOPT_POST => true, 
                            CURLOPT_POSTFIELDS => json_encode($params), 
                            CURLOPT_HTTPHEADER => $header
                        );

                        $ch = curl_init();
                        curl_setopt_array($ch, $options);
                        $response2 = curl_exec($ch);

                        if (!$response2) {
                            $error_message = curl_error($ch);
                            curl_close($ch);
                        } else {
                            curl_close($ch);
                            $result = json_decode($response2, true);
                            $this->log($options);
                            $this->log($result);
                            if ($result['status_code'] == 200) {
                                $order->delete_meta_data('OctiFi_Charge_Id');
                                $order->delete_meta_data('OctiFi_Txn_Number');
                                $order->add_meta_data('OctiFi_Charge_Id', $result['data']['charge_id']);
                                $order->add_meta_data('OctiFi_Txn_Number', $result['data']['order_payment_details']['data']['txn_number']);
                                $order->save_meta_data();
                                
                                if ($is_capture) {
                                    /*$params = array(
                                        "charge_id" => $result['data']['charge_id']
                                    );
                                     */
                                    
                                    $OctiFi_Charge_Id = $result['data']['charge_id'];

                                    $options2 = array(
                                        CURLOPT_URL => getOctifiEnv('OCTIFI_CHARGE_DETAIL_URL').$OctiFi_Charge_Id."/",
                                        CURLOPT_RETURNTRANSFER => true, 
                                        CURLOPT_HEADER => false, 
                                        CURLOPT_SSL_VERIFYPEER => false, 
                                        //CURLOPT_POST => true, 
                                        //CURLOPT_POSTFIELDS => json_encode($params), 
                                        CURLOPT_HTTPHEADER => $header
                                    );

                                    $ch2 = curl_init();
                                    curl_setopt_array($ch2, $options2);
                                    $response3 = curl_exec($ch2);

                                    if (!$response3) {
                                        $error_message = curl_error($ch2);
                                        curl_close($ch2);
                                    } else {
                                        curl_close($ch2);
                                        $result2 = json_decode($response3, true);
                                        $this->log($options2);
                                        $this->log($result2);
                                        if ($result2['status_code'] == 200) {
                                            $charge_status = $result2['data']['state'];
                                            
                                            $order->delete_meta_data('OctiFi_Captured');
                                            $capture_status = 0;
                                            if ($charge_status == 'ChargeState.CAPTURED') {
                                                $capture_status = 1;
                                            }
                                            $order->add_meta_data('OctiFi_Captured', $capture_status);
                                            $order->save_meta_data();
                                            
                                            $order->update_status('processing', __('Payment successful with OctiFi(Authorized and Captured). Charge Status: '.$charge_status.'.', $this->domain));
                                            wp_redirect($this->get_return_url($order));
                                        } else {
                                            $error_message = $result2['message'];
                                        }
                                    }
                                } else {
                                    $charge_status = $result['data']['order_detail']['status'];
                                    $order->update_status('processing', __('Payment successful with OctiFi (Authorized). Charge Status: '.$charge_status.'.', $this->domain));
                                    wp_redirect($this->get_return_url($order));
                                }
                            } else {
                                $error_message = $result['message'];
                                $order->delete_meta_data('OctiFi_Charge_Id');
                                $order->delete_meta_data('OctiFi_Txn_Number');

                                if (isset($result['data']['charge_id'])) {
                                    $order->add_meta_data('OctiFi_Charge_Id', $result['data']['charge_id']);
                                }
                                if (isset($result['data']['order_payment_details']['data']['txn_number'])) {
                                    $order->add_meta_data('OctiFi_Txn_Number', $result['data']['order_payment_details']['data']['txn_number']);
                                }
                                $order->save_meta_data();
                            }
                        }
                    } else {
                        $error_message =  __('No Checkout Token from OctiFi', $this->domain);
                    }

                    if ($error_message) {
                        wc_add_notice(__('Payment error: ', 'woocommerce') . $error_message);
                        $order->update_status('failed', __('Payment Failed with OctiFi. Reason: '.$error_message, $this->domain));
                        $error_message = base64_encode($error_message);
                        wp_redirect($this->get_return_url($order).'&octifierr='.$error_message);
                    }

                } else {
                    $search = 'failed?data';
                    if (strpos($checkout, $search) !== false || $checkout == 'failed') {
                        if ($checkout == 'failed') {
                            $response['errorcode'] = $_REQUEST['errorcode'];
                            $response['merchant_order_id'] = $_REQUEST['merchant_order_id'];
                            $response['statuscode'] = $_REQUEST['statuscode'];
                        } else {
                            $data = str_replace($search, '', $checkout);
                            $jsonData =  base64_decode($data);
                            $response = json_decode($jsonData, true);
                        }
                        
                        $error_message = $response['errorcode'];
                        if (is_array($response['errorcode'])) {
                            $error_message = $response['errorcode'][0];
                        }

                        $order_id = $response['merchant_order_id'];
                        $order = new WC_Order($order_id);
                        $order->update_status('failed', __('Payment Failed with OctiFi. Reason: '.$error_message, $this->domain));

                        $order->add_meta_data('OctiFi_Payment_Status_Code', $response['statuscode']);
                        $order->save_meta_data();

                        $error_message = base64_encode($error_message);
                        wp_redirect($this->get_return_url($order).'&octifierr='.$error_message);
                    }
                }
            }
            exit;
        }

        /**
         * Process the payment and return the result.
         *
         * @param int $order_id
         * @return array
         */
        public function process_payment($order_id) {
            $order = wc_get_order($order_id);
            return array(
                'result' => 'success',
                'redirect' => $order->get_checkout_payment_url( true )
            );
        }
        
        public function get_site_logo()
        {
            $custom_logo_id = get_theme_mod( 'custom_logo' );
            $image = wp_get_attachment_image_src( $custom_logo_id , 'full' );
            return $image[0];
        }
        
        public function log($content) {
            $debug = OCTIFI_DEBUG;
            if ($debug == true) {
                $file = OCTIFI_PLUGIN_PATH.'debug.log';
                $fp = fopen($file, 'a+');
                fwrite($fp, "\n");
                fwrite($fp, date("Y-m-d H:i:s").": ");
                fwrite($fp, print_r($content, true));
                fclose($fp);
            }
        }
    }
}

add_filter('woocommerce_payment_gateways', 'add_octifi_gateway_class');
function add_octifi_gateway_class($methods) {
    $methods[] = 'WC_OctiFi';
    return $methods;
}

add_filter( 'woocommerce_available_payment_gateways', 'enable_octifi_gateway' );
function enable_octifi_gateway( $available_gateways ) {
    if ( is_admin() ) return $available_gateways;

    if ( isset( $available_gateways['octifi'] )) {
        $settings = get_option('woocommerce_octifi_settings');
        
        if(empty($settings['api_key'])) {
            unset( $available_gateways['octifi'] );
        }
        if(empty($settings['private_api_key'])) {
            unset( $available_gateways['octifi'] );
        }
    } 
    return $available_gateways;
}

