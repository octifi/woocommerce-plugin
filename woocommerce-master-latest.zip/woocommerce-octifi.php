<?php
/*
  Plugin Name: OctiFi Payment
  Description: Allows payments by mobile phone with OctiFi. Contact info@octifi.com if any queries.
  Author: <a href="https://octifi.com/">OctiFi</a>   
  Version: 2.0.5
  
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

define('OCTIFI_PLUGIN_URL', plugin_dir_url(__FILE__));
define('OCTIFI_PLUGIN_PATH', plugin_dir_path(__FILE__));
define('OCTIFI_DEBUG', false);

include_once OCTIFI_PLUGIN_PATH.'vendor/octifienv/loader.php';

/**
 * Initiate OctiFi Payment once plugin is ready
 */
add_action('plugins_loaded', 'woocommerce_octifi_init');
function woocommerce_octifi_init() {

    class WC_OctiFi extends WC_Payment_Gateway {

        public $domain;

        /**
         * Constructor for the gateway.
         */
        public function __construct() {
            $this->domain = 'octifi';

            $this->id = 'octifi';
            $this->icon = OCTIFI_PLUGIN_URL . 'assets/images/logo.png';
            $this->has_fields = false;
            $this->method_title = __('OctiFi Payment', $this->domain);
            $this->method_description = __('Allows payments by mobile phone with OctiFi. Contact info@octifi.com if any queries.', $this->domain);
            
            // Define user set variables
            $this->title = $this->get_option('title');
            $this->description = $this->get_option('description');
            $this->api_key = $this->get_option('api_key');
            $this->private_api_key = $this->get_option('private_api_key');
            $this->payment_type = $this->get_option('payment_type');
            $this->payment_action = $this->get_option('payment_action');

	    // Load the settings.
            $this->init_form_fields();
            $this->init_settings();

            // Actions
            add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
            add_action('woocommerce_receipt_' . $this->id, array( $this, 'receipt_page' ));
            add_action('woocommerce_thankyou_' . $this->id, array($this, 'thankyou_page'));
            add_action('woocommerce_api_'. strtolower("WC_OctiFi"), array( $this, 'check_ipn_response' ) );
            add_action( 'woocommerce_order_status_completed', array( $this, 'order_completed'), 10, 1);
            add_action( 'woocommerce_admin_order_data_after_order_details', array( $this, 'admin_order_details'), 10, 3 );
        }

        /**
         * Initialize Gateway Settings Form Fields.
         */
        public function init_form_fields() {
	    $field_arr = array(
                'enabled' => array(
                    'title' => __('Enable/Disable', $this->domain),
                    'type' => 'checkbox',
                    'label' => __('Enable OctiFi Payment', $this->domain),
                    'default' => 'yes'
                ),
                'title' => array(
                    'title' => __('Title', $this->domain),
                    'type' => 'text',
                    'description' => __('This controls the title which the user sees during checkout.', $this->domain),
                    'default' => $this->method_title,
                    'desc_tip' => true,
                ),
               'description' => array(
                    'title' => __('Instructions', $this->domain),
                    'type' => 'textarea',
                    'description' => __('Instructions that that the customer will see on your checkout.', $this->domain),
                    'desc_tip' => true,
                    'default' => __('<p class="checkout-text-octifi">Pay only '.get_woocommerce_currency_symbol().'<span id="checkout-newpayment">0</span> today with <img src="'.OCTIFI_PLUGIN_URL.'assets/images/logo.png" width="50px"> instalments</p><p id="OpenDialog">Learn more>></p>', $this->domain),
                ),
                'api_key' => array(
                    'title' => __('Public API Key', $this->domain),
                    'type' => 'text',
                ),
                'private_api_key' => array(
                    'title' => __('Private API Key', $this->domain),
                    'type' => 'text',
                ),
                'payment_type' => array(
                    'title' => __('Choose Payment Type', $this->domain),
                    'id' => 'payment_type',
                    'type' => 'payment_type',
                    'default' => 'redirect',
                    'options' => $this->getPaymentTypes()
                ),
                'payment_action' => array(
                    'title' => __('Payment Action', $this->domain),
                    'type' => 'select',
                    'default' => 'capture',
                    'options' => $this->getPaymentActions()
                ),
            );

            $this->form_fields = $field_arr;
        }
        
        public function getPaymentTypes() {
            $types = [
                'redirect' => __('Redirect', $this->domain),
                'hosted' => __('Modal Popup', $this->domain),
            ];
            return $types;
        }
        
        public function getPaymentActions() {
            return [
                'authorise' => __('Authorization', $this->domain),
                'capture' => __('Authorise & Capture', $this->domain),
            ];
        }
        
        public function generate_payment_type_html( $key, $value ) { 
            $payment_type = $this->settings['payment_type'];
            if (empty($payment_type)) {
                $payment_type = $value['default'];
            }
            $html = '<tr valign="top">
                    <th scope="row" class="titledesc">
                        <label for="woocommerce_octifi_'.$key.'">'. $value['title'].'</label>
                    </th>
                    <td class="forminp forminp-'.$key.'">
                    <fieldset>';
                    foreach($value['options'] as $type => $option) {    
                        $html .= '<label for="woocommerce_octifi_'.$key.'_'.$type.'">'
                                . '<input '
                                . 'type="radio" '
                                . 'name="woocommerce_octifi_'.$key.'" '
                                . 'id="woocommerce_octifi_'.$key.'_'.$type.'" '
                                . 'value="'.$type.'" '
                                . (($payment_type == $type) ? 'checked="checked"':'').'> '.$option.'</label>&nbsp;&nbsp;';
                    }
                    $html .= '</fieldset>
                    </td>
                </tr>';
            return $html;
        }

        /**
         * Process Gateway Settings Form Fields.
         */
	public function process_admin_options() {
            $this->init_settings();

            $post_data = $this->get_post_data();
            if (empty($post_data['woocommerce_octifi_api_key'])) {
                WC_Admin_Settings::add_error(__('Please enter OctiFi Public API Key', $this->domain));
            } else if (empty($post_data['woocommerce_octifi_private_api_key'])) {
                WC_Admin_Settings::add_error(__('Please enter OctiFi Private API Key', $this->domain));
            } else {
                foreach ( $this->get_form_fields() as $key => $field ) {
                    $setting_value = $this->get_field_value( $key, $field, $post_data );
                    $this->settings[ $key ] = $setting_value;
                }
                return update_option( $this->get_option_key(), apply_filters( 'woocommerce_settings_api_sanitized_fields_' . $this->id, $this->settings ) );
            }
	}
        
        /**
        * Receipt page
        *
        * @param  int $order_id Order ID.
        */
        public function receipt_page( $order_id ) {
            global $woocommerce;
            
            $order = wc_get_order($order_id);
            $order_data = $order->get_data();
            
            $order->delete_meta_data('OctiFi_Payment_Action');
            $order->add_meta_data('OctiFi_Payment_Action', $this->payment_action);
            $order->save_meta_data();
            
            $product_name = '';
            foreach ($order->get_items() as  $item) {
                $product_name .= $item->get_name().';'; 
            }
            $params['product_name'] = $product_name;
            
            if ($this->payment_type == 'redirect') {
                include_once OCTIFI_PLUGIN_PATH.'templates/redirect.php';
            } else {
                include_once OCTIFI_PLUGIN_PATH.'templates/modal.php';
            }
        }

        /**
         * Output for the order received page.
         */
        public function thankyou_page($order_id) 
        {
            global $woocommerce;
            
            $order = new WC_Order($order_id);
            $status = $order->get_status();
            if ($status == 'pending') {
                $style = "width: 100%;  margin-bottom: 1rem; background: #00ccb8; padding: 20px; color: #fff; font-size: 22px;";
            ?>
                <div class="payment-panel">
                    <div style="<?php echo $style?>">
                    <?php echo __('Your payment status is pending, we will update the status as soon as we receive notification from OctiFi Payment System.', $this->domain) ?>
                    </div>
                </div>
            <?php
            } else if ($status == 'processing') {
                $style = "width: 100%;  margin-bottom: 1rem; background: green; padding: 20px; color: #fff; font-size: 22px;";
                $woocommerce->cart->empty_cart();
            ?>
                <div class="payment-panel">
                    <div style="<?php echo $style?>">
                    <?php echo __('Your payment is successful with OctiFi Payment System.', $this->domain) ?>
                    </div>
                </div>
            <?php    
            } else if ($status == 'failed') {
                $style = "width: 100%;  margin-bottom: 1rem; background: indianred; padding: 20px; color: #fff; font-size: 22px;";
                $error_message = '';
                if (isset($_GET['octifierr'])) {
                    $error_message = base64_decode($_GET['octifierr']);
                    $woocommerce->cart->empty_cart();
                }
            ?>
                 <div class="payment-panel">
                    <div style="<?php echo $style?>">
                    <?php echo __('Your payment is failed with OctiFi System. ', $this->domain) ?>
                    <?php if (!empty($error_message)) {?>
                        <?php echo $error_message ?>
                    <?php }?>
                    </div>
                </div>
            <?php
            } else if ($status == 'cancelled') {
                $style = "width: 100%;  margin-bottom: 1rem; background: indianred; padding: 20px; color: #fff; font-size: 22px;";
            ?>
                 <div class="payment-panel">
                    <div style="<?php echo $style?>">
                    <?php echo __('Your order is cancelled.', $this->domain) ?>
                    </div>
                </div>
            <?php
            }
        }
        
        public function admin_order_details( $order ){
            if ($order->get_payment_method() == $this->id) {
                $order_id = $order->get_id();
                
                $status_message = '';
                $status = '';
                
                if (isset($_GET['octifi_capture'])) {
                    $charge_id = get_post_meta( $order_id, 'OctiFi_Charge_Id', true );
                    if (!empty($charge_id)) {
                        $header = array(
                            "accept: application/json",
                            "Content-Type: application/json",
                            "Authorization: Api-Key ".$this->private_api_key
                        );
                        
                        $params = array(
                            "charge_id" => $charge_id
                        );

                        $options2 = array(
                            CURLOPT_URL => getOctifiEnv('OCTIFI_CHARGE_URL'), 
                            CURLOPT_RETURNTRANSFER => true, 
                            CURLOPT_HEADER => false, 
                            CURLOPT_SSL_VERIFYPEER => false, 
                            CURLOPT_POST => true, 
                            CURLOPT_POSTFIELDS => json_encode($params), 
                            CURLOPT_HTTPHEADER => $header
                        );

                        $ch2 = curl_init();
                        curl_setopt_array($ch2, $options2);
                        $response3 = curl_exec($ch2);

                        if (!$response3) {
                            $message = curl_error($ch2);
                            $status_message = $message;
                            curl_close($ch2);
                            $status = 'error';
                        } else {
                            curl_close($ch2);
                            $result2 = json_decode($response3, true);
                            $this->log($options2);
                            $this->log($result2);
                            if ($result2['status_code'] == 200) {
                                $message = $result2['message'];
                                if($message == 'This charge has already been captured') {
                                    $status_message = $message;
                                    $status = 'error';
                                } else {
                                    $charge_status = $result2['data']['ChargeStatus'];
                                    $message = __('Payment successful with OctiFi(Captured). Charge Status: '.$charge_status.'.', $this->domain);
                                    $status_message = __('Payment Captured Successfully.', $this->domain);
                                    $status = 'success';

                                    $order->delete_meta_data('OctiFi_Captured');
                                    $capture_status = 1;
                                    $order->add_meta_data('OctiFi_Captured', $capture_status);
                                    $order->save_meta_data();
                                }
                                            
                            } else {
                                $message = $result2['message'];
                                $status_message = $message;
                            }
                        }
                        $order->add_order_note( $message );
                    } else {
                        $status_message = __('Charge ID not found. ', $this->domain);
                        $status = 'error';
                    }
                } 
                
                $capture_url = get_edit_post_link($order_id).'&octifi_capture=1';
                
                $captured = (int)get_post_meta( $order_id, 'OctiFi_Captured', true );
                $charge_id = get_post_meta( $order_id, 'OctiFi_Charge_Id', true );
                $payment_action = get_post_meta( $order_id, 'OctiFi_Payment_Action', true );
                
                $style = "display: inline-block;margin-top: 20px;width: 100%;max-width: 100%;overflow: hidden;border-radius: 2px; text-align:center;";

                if (!empty($status_message)) {
                    $status_style = 'display: inline-block;margin-top: 30px;width: 100%;max-width: 100%;overflow: hidden; font-weight:600;';
                    if ($status == 'error') {
                        $status_style .= 'color: red;';
                    } else if ($status == 'success') {
                        $status_style .= 'color: green;';
                    }
                    echo '<div style="'.$status_style.'">'.$status_message.'</div>';
                }
                
                if ($captured == 1) {
                    $style .= 'border:3px solid green;';
            ?>
                <div style="<?php echo $style ?>">
                    <div style="padding: 10px; font-size: 16px; color: green">
                    <?php echo __('Octifi Payment Captured.', $this->domain) ?>
                    </div>
                </div>
            <?php
                } else {
                    $style .= 'border:2px solid orange;';
            ?>
                <div style="<?php echo $style ?>">
                    <div style="padding: 10px; ">
                        <a href="<?php echo $capture_url?>" class="button button-primary"><?php echo __('Capture Octifi Payment', $this->domain) ?></a>
                    </div>
                </div>
            <?php         
                }
            }
        }
        
        public function order_completed($order_id) {
            global $woocommerce;
            $payment_action = get_post_meta( $order_id, 'OctiFi_Payment_Action', true );
            if ($payment_action == 'authorise') {
                $order = new WC_Order($order_id);
                if ($order->get_payment_method() == $this->id) {
                    $charge_id = get_post_meta( $order->id, 'OctiFi_Charge_Id', true );
                    if (!empty($charge_id)) {
                        $header = array(
                            "accept: application/json",
                            "Content-Type: application/json",
                            "Authorization: Api-Key ".$this->private_api_key
                        );
                        
                        $params = array(
                            "charge_id" => $charge_id
                        );

                        $options2 = array(
                            CURLOPT_URL => getOctifiEnv('OCTIFI_CHARGE_URL'), 
                            CURLOPT_RETURNTRANSFER => true, 
                            CURLOPT_HEADER => false, 
                            CURLOPT_SSL_VERIFYPEER => false, 
                            CURLOPT_POST => true, 
                            CURLOPT_POSTFIELDS => json_encode($params), 
                            CURLOPT_HTTPHEADER => $header
                        );

                        $ch2 = curl_init();
                        curl_setopt_array($ch2, $options2);
                        $response3 = curl_exec($ch2);

                        if (!$response3) {
                            $message = curl_error($ch2);
                            curl_close($ch2);
                        } else {
                            curl_close($ch2);
                            $result2 = json_decode($response3, true);
                            $this->log($options2);
                            $this->log($result2);
                            if ($result2['status_code'] == 200) {
                                $charge_status = $result2['data']['ChargeStatus'];
                                $message = __('Payment successful with OctiFi(Captured). Charge Status: '.$charge_status.'.', $this->domain);
                                $capture_status = 1;
                                $order->add_meta_data('OctiFi_Captured', $capture_status);
                                $order->save_meta_data();
                            } else {
                                $message = $result2['message'];
                            }
                        }
                        $order->add_order_note( $message );
                    }
                }
            }
            
        }
        
        public function check_ipn_response() {
            global $woocommerce;

            if(isset($_REQUEST['checkout'])) {
                $checkout = $_REQUEST['checkout'];

                $search = 'success?data';
                if (strpos($checkout, $search) !== false || $checkout == 'success') {
                    if ($checkout == 'success') {
                        $response['checkout_token'] = $_REQUEST['checkout_token'];
                        $response['merchant_order_id'] = $_REQUEST['merchant_order_id'];
                        $response['statuscode'] = $_REQUEST['statuscode'];
                    } else {
                        $data = str_replace($search, '', $checkout);
                        $jsonData =  base64_decode($data);
                        $response = json_decode($jsonData, true);
                    }

                    $error_message = '';

                    $order_id = $response['merchant_order_id'];
                    $order = new WC_Order($order_id);
                    if ($response['statuscode'] == 200) {

                        $checkout_token = $response['checkout_token'];

                        $order->delete_meta_data('OctiFi_Checkout_Token');
                        $order->add_meta_data('OctiFi_Checkout_Token', $checkout_token);
                        $order->save_meta_data();
   
                        $header = array(
                            "accept: application/json",
                            "Content-Type: application/json",
                            "Authorization: Api-Key ".$this->private_api_key
                        );
                        
                        $is_capture = false;
                        if ($this->payment_action == 'capture') {
                            $is_capture = true;
                        }

                        $params = array(
                            "bill_total_amount" => $order->get_total(),
                            "bill_currency" => $order->get_currency(),
                            "bill_tax_amount" => $order->get_total_tax(), 
                            "is_capture" => $is_capture
                        );

                        $options = array(
                            CURLOPT_URL => getOctifiEnv('OCTIFI_CREATE_URL').$checkout_token."/", 
                            CURLOPT_RETURNTRANSFER => true, 
                            CURLOPT_HEADER => false, 
                            CURLOPT_SSL_VERIFYPEER => false, 
                            CURLOPT_POST => true, 
                            CURLOPT_POSTFIELDS => json_encode($params), 
                            CURLOPT_HTTPHEADER => $header
                        );

                        $ch = curl_init();
                        curl_setopt_array($ch, $options);
                        $response2 = curl_exec($ch);

                        if (!$response2) {
                            $error_message = curl_error($ch);
                            curl_close($ch);
                        } else {
                            curl_close($ch);
                            $result = json_decode($response2, true);
                            $this->log($options);
                            $this->log($result);
                            if ($result['status_code'] == 200) {
                                $order->delete_meta_data('OctiFi_Charge_Id');
                                $order->delete_meta_data('OctiFi_Txn_Number');
                                $order->add_meta_data('OctiFi_Charge_Id', $result['data']['charge_id']);
                                $order->add_meta_data('OctiFi_Txn_Number', $result['data']['order_payment_details']['data']['txn_number']);
                                $order->save_meta_data();
                                
                                if ($is_capture) {
                                    /*$params = array(
                                        "charge_id" => $result['data']['charge_id']
                                    );
                                     */
                                    
                                    $OctiFi_Charge_Id = $result['data']['charge_id'];

                                    $options2 = array(
                                        CURLOPT_URL => getOctifiEnv('OCTIFI_CHARGE_DETAIL_URL').$OctiFi_Charge_Id."/",
                                        CURLOPT_RETURNTRANSFER => true, 
                                        CURLOPT_HEADER => false, 
                                        CURLOPT_SSL_VERIFYPEER => false, 
                                        //CURLOPT_POST => true, 
                                        //CURLOPT_POSTFIELDS => json_encode($params), 
                                        CURLOPT_HTTPHEADER => $header
                                    );

                                    $ch2 = curl_init();
                                    curl_setopt_array($ch2, $options2);
                                    $response3 = curl_exec($ch2);

                                    if (!$response3) {
                                        $error_message = curl_error($ch2);
                                        curl_close($ch2);
                                    } else {
                                        curl_close($ch2);
                                        $result2 = json_decode($response3, true);
                                        $this->log($options2);
                                        $this->log($result2);
                                        if ($result2['status_code'] == 200) {
                                            $charge_status = $result2['data']['state'];
                                            
                                            $order->delete_meta_data('OctiFi_Captured');
                                            $capture_status = 0;
                                            if ($charge_status == 'ChargeState.CAPTURED') {
                                                $capture_status = 1;
                                            }
                                            $order->add_meta_data('OctiFi_Captured', $capture_status);
                                            $order->save_meta_data();
                                            
                                            $order->update_status('processing', __('Payment successful with OctiFi(Authorized and Captured). Charge Status: '.$charge_status.'.', $this->domain));
                                            wp_redirect($this->get_return_url($order));
                                        } else {
                                            $error_message = $result2['message'];
                                        }
                                    }
                                } else {
                                    $charge_status = $result['data']['order_detail']['status'];
                                    $order->update_status('processing', __('Payment successful with OctiFi (Authorized). Charge Status: '.$charge_status.'.', $this->domain));
                                    wp_redirect($this->get_return_url($order));
                                }
                            } else {
                                $error_message = $result['message'];
                                $order->delete_meta_data('OctiFi_Charge_Id');
                                $order->delete_meta_data('OctiFi_Txn_Number');

                                if (isset($result['data']['charge_id'])) {
                                    $order->add_meta_data('OctiFi_Charge_Id', $result['data']['charge_id']);
                                }
                                if (isset($result['data']['order_payment_details']['data']['txn_number'])) {
                                    $order->add_meta_data('OctiFi_Txn_Number', $result['data']['order_payment_details']['data']['txn_number']);
                                }
                                $order->save_meta_data();
                            }
                        }
                    } else {
                        $error_message =  __('No Checkout Token from OctiFi', $this->domain);
                    }

                    if ($error_message) {
                        wc_add_notice(__('Payment error: ', 'woocommerce') . $error_message);
                        $order->update_status('failed', __('Payment Failed with OctiFi. Reason: '.$error_message, $this->domain));
                        $error_message = base64_encode($error_message);
                        wp_redirect($this->get_return_url($order).'&octifierr='.$error_message);
                    }

                } else {
                    $search = 'failed?data';
                    if (strpos($checkout, $search) !== false || $checkout == 'failed') {
                        if ($checkout == 'failed') {
                            $response['errorcode'] = $_REQUEST['errorcode'];
                            $response['merchant_order_id'] = $_REQUEST['merchant_order_id'];
                            $response['statuscode'] = $_REQUEST['statuscode'];
                        } else {
                            $data = str_replace($search, '', $checkout);
                            $jsonData =  base64_decode($data);
                            $response = json_decode($jsonData, true);
                        }
                        
                        $error_message = $response['errorcode'];
                        if (is_array($response['errorcode'])) {
                            $error_message = $response['errorcode'][0];
                        }

                        $order_id = $response['merchant_order_id'];
                        $order = new WC_Order($order_id);
                        $order->update_status('failed', __('Payment Failed with OctiFi. Reason: '.$error_message, $this->domain));

                        $order->add_meta_data('OctiFi_Payment_Status_Code', $response['statuscode']);
                        $order->save_meta_data();

                        $error_message = base64_encode($error_message);
                        wp_redirect($this->get_return_url($order).'&octifierr='.$error_message);
                    }
                }
            }
            exit;
        }

        /**
         * Process the payment and return the result.
         *
         * @param int $order_id
         * @return array
         */
        public function process_payment($order_id) {
            $order = wc_get_order($order_id);
            return array(
                'result' => 'success',
                'redirect' => $order->get_checkout_payment_url( true )
            );
        }
        
        public function get_site_logo()
        {
            $custom_logo_id = get_theme_mod( 'custom_logo' );
            $image = wp_get_attachment_image_src( $custom_logo_id , 'full' );
            return $image[0];
        }
        
        public function log($content) {
            $debug = OCTIFI_DEBUG;
            if ($debug == true) {
                $file = OCTIFI_PLUGIN_PATH.'debug.log';
                $fp = fopen($file, 'a+');
                fwrite($fp, "\n");
                fwrite($fp, date("Y-m-d H:i:s").": ");
                fwrite($fp, print_r($content, true));
                fclose($fp);
            }
        }
    }
}

add_filter('woocommerce_payment_gateways', 'add_octifi_gateway_class');
function add_octifi_gateway_class($methods) {
    $methods[] = 'WC_OctiFi';
    return $methods;
}

add_filter( 'woocommerce_available_payment_gateways', 'enable_octifi_gateway' );
function enable_octifi_gateway( $available_gateways ) {
    if ( is_admin() ) return $available_gateways;

    if ( isset( $available_gateways['octifi'] )) {
        $settings = get_option('woocommerce_octifi_settings');
        
        if(empty($settings['api_key'])) {
            unset( $available_gateways['octifi'] );
        }
        if(empty($settings['private_api_key'])) {
            unset( $available_gateways['octifi'] );
        }
    } 
    return $available_gateways;
}
add_action( 'woocommerce_checkout_order_review', 'woocommrece_checkout_text', 50 );
function woocommrece_checkout_text(){
global $woocommerce;
$amount2 = floatval( preg_replace( '#[^\d.]#', '', WC()->cart->total ) );
$final_amount= $amount2/3;
$final_amount=(int)$final_amount;
?>
<script>
jQuery( document ).ready(function() {
	
	console.log('payment method '+jQuery('input[name="payment_method"]:checked').val());
	if(jQuery('input[name="payment_method"]:checked').val() == 'octifi'){
		var rval=<?php echo $final_amount; ?>;
		console.log('hii in if: '+rval);
	
		jQuery("#checkout-newpayment").text(rval);
	
	
		setTimeout(function(){
			console.log(rval);
			jQuery("#checkout-newpayment").text(rval);

		},2000); 
	}else{
		jQuery(document).on('change','input[name="payment_method"]',function(){
		
			if(jQuery(this).val() == 'octifi'){
				var rval=<?php echo $final_amount; ?>;
			console.log('hii on change: '+rval);
		
			jQuery("#checkout-newpayment").text(rval);
			}
		});
		 
	}

//jQuery(".payment_box p").on("click", function() {
jQuery('body').on('click','#OpenDialog',function(){	
	console.log('clciked');
  jQuery('body').append('<div class="modal-backdrop fade show"></div>');
  jQuery(".popup-overlay, .popup-content").addClass("active");
   jQuery(".modal-ocitifi").addClass("show");
  
});

jQuery('body').on('click','#OpenDialog',function(){	
	console.log('clciked');
	 jQuery("body").addClass("popup-new");
  jQuery(".popup-overlay, .popup-content").addClass("active");
    
});


//removes the "active" class to .popup and .popup-content when the "Close" button is clicked 


jQuery(document).on('click','.modal-backdrop',function(){
	
	jQuery(".popup-overlay, .popup-content").removeClass("active");
	   jQuery(".modal-ocitifi").removeClass("show");
	jQuery(this).remove();	
});

jQuery(document).on('click','.close-btn',function(){
	
	jQuery(".popup-overlay, .popup-content").removeClass("active");
	   jQuery(".modal-ocitifi").removeClass("show");
	    jQuery("body").removeClass("popup-new");
	jQuery(".modal-backdrop").remove();	
});

});
</script>
<!--Creates the popup body-->
<div class="modal-ocitifi">
	<div class="moda-ocitifi-dialog">
		<div class="modal-content-wrap">
			<div class="popup-overlay">
				<!--Creates the popup content-->
				<div class="popup-content">
					<a href="#" class="close-btn">X</a>
					<div class="top-head-image">
						<img src="<?php echo OCTIFI_PLUGIN_URL; ?>assets/images/logo.png" class="img-fluid" alt="logo">
						<h5 class="head-title">Be the savvy customer and choose OctiFi at checkout </h5>
					</div>
					<div class="cstm-row">
						<div class="cstm-col">
							<div class="checkout-card">
								<img src="<?php echo OCTIFI_PLUGIN_URL; ?>assets/images/Pay-only-1_3-today-icon.gif" class="img-fluid" alt="card-img">
								<h6>Pay only 1/3 today</h6>
								<p>We pay the store full, and you pay us in 3 instalment,  <b>0% interest with no hidden fees</b></p>
							</div>
						</div>
						
						<div class="cstm-col">
							<div class="checkout-card  both-debit">
								<img src="<?php echo OCTIFI_PLUGIN_URL; ?>assets/images/Usebothcreditn debitcard.gif" class="img-fluid" alt="card-img">
								<h6>Use both debit or credit card</h6>
								<p>No credit card? No problem! We accept any Singapore Banks issue debit cards.</p>
							</div>
						</div>
						
						<div class="cstm-col">
							<div class="checkout-card">
								<img src="<?php echo OCTIFI_PLUGIN_URL; ?>assets/images/Earncashbackicon.gif" class="img-fluid" alt="card-img">
								<h6>Earn 1.5% cashback </h6>
								<p>Have more cash to spare? Pay more upfront and earn additional 1.5% cashback from us!</p>
							</div>
						</div>
					</div>
					<div class="footer-title">
						<h5 class="head-title">Pay with your preferred payment methods</h5>
						<ul class="payment-img">
							<li><img src="<?php echo OCTIFI_PLUGIN_URL; ?>assets/images/visa.png"></li>
							<li><img src="<?php echo OCTIFI_PLUGIN_URL; ?>assets/images/mastercard.png"></li>
							<li class="american-img"><img src="<?php echo OCTIFI_PLUGIN_URL; ?>assets/images/American-express.png"></li>
						</ul>
						<div class="link-footer">
							<p>Terms and Condition Applies.<a href="https://www.octifi.com/en/terms.html">See full Ts & Cs here >></a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<style>
@import url('https://fonts.googleapis.com/css2?family=Krub:wght@200;300;400;500;600;700&display=swap');
.modal-backdrop.show {
    opacity: .5;
}
.modal-backdrop.fade {
    opacity: 0;
}
.fade.show {
    opacity: 0.4;
}
.modal-backdrop {
    z-index: 1071;
}
.modal-backdrop {
    position: fixed;
    top: 0;
    right: 0;
    bottom: 0;
    left: 0;
    z-index: 1;
    background-color: #000;
}
.fade {
    opacity: 0;
    transition: opacity .15s linear;
}
.popup-overlay {
	font-family: 'Krub', sans-serif;
    visibility: hidden;
    position: absolute;   
    transform: translate(-50%, -50%) translateY(-15%);
    background: #ffffff;
    border: none;
    width: 100%;
    margin: 0 auto;
    height: auto;
    box-shadow: 0px 1px 7px -3px #585858;
    border-radius: 100px;
    z-index: 9;
    padding: 30px;
    transition: transform .3s ease-in;
}
.modal-ocitifi {
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    z-index: 999;
    height: 84vh;
    max-width: 586px;
    width: 100%;
    opacity: 0;
    display: none;
	overflow-x: hidden;
    overflow-y: auto;
}
.modal-ocitifi.show {
    display: block;
    opacity: 1;
    visibility: visible;
}
.moda-ocitifi-dialog {
    min-height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    width: 100%;
}
.popup-overlay.active {
  /*displays pop-up when "active" class is present*/
  visibility: visible;
  text-align: center;
  transform: translate(-50%, -50%) translateY(0);
    transition: transform .3s ease-in;
}


.popup-content {
  /*Hides pop-up content when there is no "active" class */
  visibility: hidden;
}

.popup-content.active {
  /*Shows pop-up content when "active" class is present */
  visibility: visible;
}

button {
  display: inline-block;
  vertical-align: middle;
  border-radius: 30px;
  margin: .20rem;
  font-size: 1rem;
  color: #666666;
  background: #ffffff;
  border: 1px solid #666666;
}

button:hover {
  border: 1px solid #666666;
  background: #666666;
  color: #ffffff;
}
.top-head-image img {
    max-width: 100%;
    width: 150px;
    margin-bottom: 0px;
}

h5.head-title {
    margin: 0 !important;
    padding: 0;
    font-family: 'Krub', sans-serif;
    color: #000;
    letter-spacing: 0;
    text-transform: unset;
    font-size: 18px;
    font-weight: 600;
}

.top-head-image h5.head-title {
    max-width: 60%;
    margin: 10px auto 0 !important;
    display: block;
    text-align: center;
    font-family: 'Krub', sans-serif;
    color: #000;
    letter-spacing: 0;
}
.checkout-text-octifi{
	margin-bottom: 0;
}
p#OpenDialog {
    color: #35b0e4;
    cursor: pointer;
}
.cstm-row {
    display: flex;
    align-items: flex-start;
    flex-wrap: wrap;
    margin-left: -15px;
    margin-right: -15px;
	padding: 0 10px;
}
.checkout-card img {
    width: 57%;
}

.cstm-row .cstm-col {
    flex: 0 0 33%;
    max-width: 33%;
    padding-left: 15px;
    padding-right: 15px;
}
.checkout-card h6 {
    margin: 0;
    padding: 0;
    max-width: 65%;
    margin: 0 auto 0 !important;
    display: block;
    text-align: center;
    font-family: 'Krub', sans-serif;
    color: #000;
	font-size: 16px;
    min-height: 70px;
    letter-spacing: 0;
}

.checkout-card p {
    color: #888;
    font-size: 14px;
}
.both-debit p {
    max-width: 90%;
    margin: 0 auto;
}
.checkout-card p b {
    color: #000;
}
ul.payment-img {
    list-style: none;
    margin: 0 0 20px;
    padding: 0;
}

ul.payment-img li {
    display: inline-block;
    width: 13%;
}

ul.payment-img li img {
    width: 60px;
    vertical-align: middle;
}
ul.payment-img li.american-img img {
    width: 45px;
}
.footer-title {
    margin-top: 20px;
}
.footer-title h5.head-title {
    font-size: 18px;
    margin-bottom: 10px !important;
}
.both-debit p {
    max-width: 90%;
    margin: 0 auto;
}

.footer-title h5.head-title {
    font-size: 18px;
    margin-bottom: 10px !important;
}

.footer-title {
    margin-top: 20px;
}

.link-footer p {
    font-size: 13px;
    color: #000;
    font-family: 'Krub', sans-serif;
    line-height: 1.3;
	margin-bottom: 0;
}

.link-footer p a {
    display: block;   
    text-decoration-color: #000;
    color: #29abe2;
    font-weight: 500;
    border: none !important;
    box-shadow: none;
}
.link-footer p a:hover {
    box-shadow: none !important;
}
.link-footer p a:focus {
    outline: none;
    box-shadow: none;
}
.modal-ocitifi .moda-ocitifi-dialog .popup-overlay .popup-content .close-btn {
    position: absolute;
    right: 20px;
    top: 20px;
    color: #000 !important;
    background: #d1d1d1;
    display: inline-block;
    width: 30px;
    height: 30px;
    line-height: 30px;
    border-radius: 100px;
    font-weight: bold;
}
.modal-backdrop {
    z-index: 1050;
}
.modal-ocitifi {
    z-index: 1060;
}
.modal-ocitifi .moda-ocitifi-dialog .popup-overlay .popup-content{
	position: relative;
}
body.popup-new {
    overflow: hidden;
}
@media (max-width: 1200px){
	.popup-overlay{
			width: 100%;
    max-width: 600px;
	}
	ul.payment-img li {
		display: inline-block;
		width: 16%;
	}
}
@media(max-width:767px){
	.modal-ocitifi {	
		overflow: hidden;
		max-width: calc(100% - 7%) !important;
		max-height: 100%;
		height: 100vh;
		padding: 15px 0;
	}

	.modal-ocitifi .moda-ocitifi-dialog {
		min-height: auto !important;
		height: 100%;
	}

	.modal-ocitifi .moda-ocitifi-dialog .popup-overlay {
		top: 0 !important;
		transform: none;
		transform: none;
		position: initial !important;
		padding-right: 0;
		overflow: hidden;
		max-height: 100%;
		border-radius: 8px;
		padding: 0px;
		height: 100%;
	}

	.modal-ocitifi .moda-ocitifi-dialog .popup-overlay .popup-content {
		max-height: calc(100vh - 30px);
		overflow-y: auto;
		overflow-x: hidden;
		    padding-top: 30px;
			    padding-bottom: 30px;
	}
	.modal-ocitifi {
		margin: 0;
		max-width: 80%;
		margin: 0 auto;
	}
	.modal-ocitifi .popup-overlay {
		margin: 0;
		max-width: 100%;
	}
	.modal-ocitifi .moda-ocitifi-dialog .modal-content-wrap {
		height: 100%;
	}
}	
@media (max-width: 575px){
	.popup-overlay {
		width: 100%;
		max-width: 85%;
		padding: 25px 15px;
		border-radius: 70px;
	}
	.cstm-row .cstm-col {
		flex: 0 0 100%;
		max-width: 100%;
	}
	.top-head-image h5.head-title {
		max-width: 75%;
	}
	.checkout-card h6{
		    margin: 0 auto 7px !important;
    	min-height: auto;
	}
	ul.payment-img li {

		width: 20%;
	}
	.checkout-card p {
		max-width: 80%;
		margin: 0 auto 0;
	}
	
.modal-ocitifi.show .popup-overlay.active {
    top: 100%;
}
}

@media (max-width: 480px){
	.top-head-image h5.head-title {
		max-width: 90%;
	}
	.checkout-card p {
		max-width: 90%;
	}
	.checkout-card img {
		width: 40%;
	}

}
@media (max-width: 420px){
	.top-head-image h5.head-title , .checkout-card p{
		max-width: 100%;
	}
	h5.head-title {
		font-size: 16px;
	}
	ul.payment-img li {
		width: 30%;
	}
	.top-head-image img {
		
		width: 120px;
	}
}
</style>
<?php }

