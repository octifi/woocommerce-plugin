<div style = "text-align:center;"> <p> <?php echo esc_html( __( 'Please wait, we are redirecting to the payment gateway...', 'octifi' ) ); ?> </p> <div id = "octif-loader"> <img src="<?php echo esc_url( OCTIFI_PLUGIN_URL ); ?>assets/images/loader.gif"> </div> </div> 
<script>
jQuery(document).ready(function() {
jQuery('.order_details').hide();
var _octifi_config = {
	modal: false,
	public_api_key: '<?php echo esc_html( $this->api_key ); ?>',
	merchant_logo: "<?php echo esc_html( $this->octifi_get_site_logo() ); ?>",
	redirect_confirmation_url_action: "GET",
	redirect_callbacks: {
		onSuccess: "<?php echo esc_url( site_url() ) . '/?wc-api=wc_octifi&checkout=success'; ?>",
		onFail: "<?php echo esc_url( site_url() ) . '/?wc-api=wc_octifi&checkout=failed'; ?>",
	}
};
octifi.initialize(_octifi_config);
octifi.checkout = {
	checkout: {
		merchant: {
			name: "<?php echo esc_html( addslashes( get_bloginfo( 'name' ) ) ); ?>" //required
		},
		bill: {
			display_name: "<?php echo esc_html( addslashes( $product_name ) ); ?>", //required
			tax_amount: <?php echo esc_html( $order->get_total_tax() ); ?> , //required
			total_amount: <?php echo esc_html( $order->get_total() ); ?> , //required
			currency: "<?php echo esc_html( $order_data['currency'] ); ?>", //required
			merchant_order_id: <?php echo esc_html( $order->get_id() ); ?> , //required
		},
		customer: {
			phone_number: "<?php echo esc_html( $order_data['billing']['phone'] ); ?>",
			mobile_number: "<?php echo esc_html( $order_data['billing']['phone'] ); ?>",
			email: "<?php echo esc_html( $order_data['billing']['email'] ); ?>",
			country_code: "<?php echo esc_html( $order_data['billing']['country'] ); ?>"
		},
		details: {
			shipping: {
				name: {
					first: "<?php echo esc_html( addslashes( $order_data['shipping']['first_name'] ) ); ?>",
					last: "<?php echo esc_html( addslashes( $order_data['shipping']['last_name'] ) ); ?>"
				},
				address: {
					line1: "<?php echo esc_html( addslashes( $order_data['shipping']['address_1'] ) ); ?>",
					line2: "<?php echo esc_html( addslashes( $order_data['shipping']['address_2'] ) ); ?>",
					city: "<?php echo esc_html( addslashes( $order_data['shipping']['city'] ) ); ?>",
					state: "<?php echo esc_html( addslashes( $order_data['shipping']['state'] ) ); ?>",
					zipcode: "<?php echo esc_html( $order_data['shipping']['postcode'] ); ?>",
					country: "<?php echo esc_html( $order_data['shipping']['country'] ); ?>"
				},
				Shipping_amount: <?php echo esc_html( $order->get_shipping_total() ); ?>,
			},
			billing: {
				name: {
					first: "<?php echo esc_html( addslashes( $order_data['billing']['first_name'] ) ); ?>",
					last: "<?php echo esc_html( addslashes( $order_data['billing']['last_name'] ) ); ?>"
				},
				address: {
					line1: "<?php echo esc_html( addslashes( $order_data['billing']['address_1'] ) ); ?>",
					line2: "<?php echo esc_html( addslashes( $order_data['billing']['address_2'] ) ); ?>",
					city: "<?php echo esc_html( addslashes( $order_data['billing']['city'] ) ); ?>",
					state: "<?php echo esc_html( addslashes( $order_data['billing']['state'] ) ); ?>",
					zipcode: "<?php echo esc_html( $order_data['billing']['postcode'] ); ?>",
					country: "<?php echo esc_html( $order_data['billing']['country'] ); ?>"
				},
				phone_number: "<?php echo esc_html( $order_data['billing']['phone'] ); ?>",
				email: "<?php echo esc_html( $order_data['billing']['email'] ); ?>"
			},
			product: [ 
			<?php foreach ( $order->get_items() as $item ) { ?>
					<?php $product = $item->get_product(); ?>
					<?php $product_id = $item->get_product_id(); ?>
					<?php $image_url = wp_get_attachment_image_src( get_post_thumbnail_id( $product_id ), 'single-post-thumbnail' ); ?> {
						display_name: "<?php echo esc_html( addslashes( $item->get_name() ) ); ?>",
						sku: "<?php echo esc_html( $product->get_sku() ); ?>",
						unit_price: <?php echo esc_attr( $product->get_price() ); ?> ,
						qty : <?php echo esc_attr( $item->get_quantity() ); ?> ,
						item_image_url : "",
						item_url: "<?php echo esc_url( get_permalink( $product_id ) ); ?>",
					}, 
					<?php } ?>
			],
			<?php if ( $order->get_discount_total() > 0 ) { ?> 
				discounts: {
					DISCOUNT: {
						discount_amount: <?php echo esc_attr( $order->get_discount_total() ); ?> ,
						discount_display_name : "Total Discount"
					}
				}, 
				<?php } ?> 
			<?php if ( $order->get_shipping_method() !== '' ) { ?> 
				metadata: {
					shipping_type: "<?php echo esc_html( addslashes( $order->get_shipping_method() ) ); ?>"
				}, 
				<?php } ?>
		},
	}
}
octifi.open(octifi.checkout);
}); </script>
