<?php
/**
 * Plugin Name: LatitudePay Payment
 * Description: Allows payments by mobile phone with LatitudePay. Contact info@octifi.com if any queries.
 * Author: LatitudePay
 * Author URI:  https://octifi.com/
 * Version: 2.1.6
 *
 * @package LatitudePay Payment
 */

// error_reporting(E_ALL)
// ini_set('display_errors', 'On').
if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

define( 'OCTIFI_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'OCTIFI_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );
define( 'OCTIFI_DEBUG', false );

require_once OCTIFI_PLUGIN_PATH . 'vendor/octifienv/loader.php';

// load styles and scripts.
add_action( 'init', 'octififunction_print_front_styling' );
function octififunction_print_front_styling() {
	$testmod = get_option( 'woocommerce_octifi_settings' );
	wp_enqueue_style( 'octifi_main_style', plugins_url( '/assets/css/front.css', __FILE__ ), null, true );

	wp_register_script( 'octifi_main_js', plugins_url( '/assets/js/front.js', __FILE__ ), array( 'jquery' ), wp_get_theme()->get( 'Version' ), 'all' );
	wp_enqueue_script( 'octifi_main_js' );

	wp_register_script( 'OCTIFI_SCRIPT_SRC', getOctifiEnv( 'OCTIFI_SCRIPT_SRC', $testmod['testmode'], $testmod['select_the_country'] ), array( 'jquery' ), wp_get_theme()->get( 'Version' ), 'all' );
	wp_enqueue_script( 'OCTIFI_SCRIPT_SRC' );
}


/**
 * Initiate OctiFi Payment once plugin is ready.
 */
add_action( 'plugins_loaded', 'octififunction_woocommerce_octifi_init' );
function octififunction_woocommerce_octifi_init() {

	class WC_OctiFi extends WC_Payment_Gateway {

		public $domain;

		/**
		 * Constructor for the gateway.
		 */
		public function __construct() {
			$this->domain             = 'octifi';
			$this->id                 = 'octifi';
			$this->icon               = OCTIFI_PLUGIN_URL . 'assets/images/logo.png';
			$this->has_fields         = false;
			$this->method_title       = __( 'LatitudePay Payment', 'octifi' );
			$this->method_description = __( 'Allows payments by mobile phone with OctiFi. Contact info@octifi.com if any queries.', 'octifi' );

			// Define user set variables.
			$this->title              = $this->get_option( 'title' );
			$this->description        = $this->get_option( 'description' );
			$this->testmode           = $this->get_option( 'testmode' );
			$this->api_key            = $this->get_option( 'api_key' );
			$this->select_the_country = $this->get_option( 'select_the_country' );
			$this->private_api_key    = $this->get_option( 'private_api_key' );
			$this->payment_type       = $this->get_option( 'payment_type' );
			$this->payment_action     = $this->get_option( 'payment_action' );
			if ( 'enable' === $this->testmode ) {
				$this->description .= '<p><span style="color:red">' . __( 'TEST MODE ENABLED', 'woocommerce-gateway-stripe' ) . '</span></p>';
				// $this->description = trim($this->description);
				$desc              = trim( $this->description );
				$symbol            = esc_html( get_woocommerce_currency_symbol() );
				$des               = str_replace( '$', $symbol, $desc );
				$des               = str_replace( '&#036;', $symbol, $desc );
				$this->description = $des;
			}

			// Load the settings.
			$this->init_form_fields();
			$this->init_settings();
			if ( ( isset( $_REQUEST['checkout'] ) ) ) {
				global $woocommerce;
				$checkout = sanitize_text_field( $_REQUEST['checkout'] );
				$search   = 'failed?data';

				if ( strpos( $checkout, $search ) === 0 ) {
					$checkout_url = $woocommerce->cart->get_checkout_url();

					header( 'Location: ' . $checkout_url );

				}
			}
			// Actions.
			add_action( 'woocommerce_update_options_payment_gateways_' . $this->id, array( $this, 'octifi_process_admin_options' ) );
			add_action( 'woocommerce_receipt_' . $this->id, array( $this, 'octifi_receipt_page' ) );
			add_action( 'woocommerce_thankyou_' . $this->id, array( $this, 'octifi_thankyou_page' ) );
			add_action( 'woocommerce_api_' . strtolower( 'WC_OctiFi' ), array( $this, 'octifi_check_ipn_response' ) );
			add_action( 'woocommerce_order_status_completed', array( $this, 'octifi_order_completed' ), 10, 1 );
			add_action( 'woocommerce_admin_order_data_after_order_details', array( $this, 'octifi_admin_order_details' ), 10, 3 );

		}

		/**
		 * Initialize Gateway Settings Form Fields.
		 */
		public function init_form_fields() {
			$symbol = get_woocommerce_currency();
			if ( get_woocommerce_currency() === 'SGD' ) {
				$val = 1;
			} elseif ( get_woocommerce_currency() === 'MYR' ) {
				$val = 2;
			} else {
				$val = 1;
			}

			$field_arr = array(
				'enabled'            => array(
					'title'   => __( 'Enable/Disable', 'octifi' ),
					'type'    => 'checkbox',
					'label'   => __( 'Enable LatitudePay Payment', 'octifi' ),
					'default' => 'yes',
				),
				'title'              => array(
					'title'       => __( 'Title', 'octifi' ),
					'type'        => 'text',
					'description' => __( 'This controls the title which the user sees during checkout.', 'octifi' ),
					'default'     => $this->method_title,
					'desc_tip'    => true,
				),
				'testmode'           => array(
					'title'   => __( 'Test mode', 'octifi' ),
					'type'    => 'select',
					'default' => 'capture',
					'options' => $this->octifi_get_testmode(),
				),
				'select_the_country' => array(
					'title'   => __( 'Select the country', 'octifi' ),
					'type'    => 'select',
					'default' => $val,
					'value'   => $val,
					'options' => $this->octifi_get_country(),
				),

				'hide_text_homepage' => array(
					'title'   => esc_html__( 'Home page text', 'octifi' ),
					'type'    => 'checkbox',
					'label'   => esc_html__( 'Hide LatitudePay instalment text on home page', 'octifi' ),
					'default' => 'yes',
				),
				'description'        => array(
					'title'       => __( 'Instructions', 'octifi' ),
					'type'        => 'textarea',
					'description' => __( 'Instructions that that the customer will see on your checkout.', 'octifi' ),
					'desc_tip'    => true,
					'default'     => __( '<p class="checkout-text-octifi">or 3 payments of ' . esc_html( get_woocommerce_currency_symbol() ) . '<span id="checkout-newpayment">0</span> or lower in <span id="OpenDialog">6 or 12 payments</span> with <img src="' . esc_url( OCTIFI_PLUGIN_URL ) . 'assets/images/logo.png"  style=" width:50%; max-width:50%; margin: 0px auto;"   >', 'octifi' ),
				),

				'api_key'            => array(
					'title' => __( 'Public API Key', 'octifi' ),
					'type'  => 'text',
				),
				'private_api_key'    => array(
					'title' => __( 'Private API Key', 'octifi' ),
					'type'  => 'text',
				),
				'min_sum'            => array(
					'title' => __( 'Minimum Sum', 'octifi' ),
					'type'  => 'text',
					// 'default' => '0'
				),
				'payment_type'       => array(
					'title'   => __( 'Choose Payment Type', 'octifi' ),
					'id'      => 'payment_type',
					'type'    => 'payment_type',
					'default' => 'redirect',
					'options' => $this->octifi_get_payment_types(),
				),
				'payment_action'     => array(
					'title'   => __( 'Payment Action', 'octifi' ),
					'type'    => 'select',
					'default' => 'capture',
					'options' => $this->octifi_get_payment_actions(),
				),
			);

			$this->form_fields = $field_arr;
		}

		public function octifi_get_payment_types() {
			$types = array(
				'redirect' => __( 'Redirect', 'octifi' ),
				// 'hosted' => __('Modal Popup', 'octifi'),
			);
			return $types;
		}
		public function octifi_get_testmode() {
			return array(
				'enable'  => __( 'enable', 'octifi' ),
				'disable' => __( 'disable', 'octifi' ),
			);
		}
		public function octifi_get_country() {
			return array(
				'1' => __( 'Singapore', 'octifi' ),
				'2' => __( 'Malaysia', 'octifi' ),
			);
		}

		public function octifi_get_payment_actions() {
			return array(
				'authorise' => __( 'Authorization', 'octifi' ),
				'capture'   => __( 'Authorise & Capture', 'octifi' ),
			);
		}

		public function generate_payment_type_html( $key, $value ) {
			$payment_type = $this->settings['payment_type'];
			if ( empty( $payment_type ) ) {
				$payment_type = $value['default'];
			}
			$html = '<tr valign="top">
                    <th scope="row" class="titledesc">
                        <label for="woocommerce_octifi_' . esc_attr( $key ) . '">' . esc_html( $value['title'] ) . '</label>
                    </th>
                    <td class="forminp forminp-' . esc_attr( $key ) . '">
                    <fieldset>';
			foreach ( $value['options'] as $type => $option ) {
				$html .= '<label for="woocommerce_octifi_' . esc_attr( $key ) . '_' . esc_attr( $type ) . '">'
						. '<input '
						. 'type="radio" '
							. 'name="woocommerce_octifi_' . esc_attr( $key ) . '" '
								. 'id="woocommerce_octifi_' . esc_attr( $key ) . '_' . esc_attr( $type ) . '" '
									. 'value="' . esc_attr( $type ) . '" '
							. ( ( $payment_type === $type ) ? 'checked="checked"' : '' ) . '> ' . esc_html( $option ) . '</label>&nbsp;&nbsp;';
			}
					$html .= '</fieldset>
                    </td>
                </tr>';
			return $html;
		}

		/**
		 * Process Gateway Settings Form Fields.
		 */
		public function octifi_process_admin_options() {
			$this->init_settings();

			$post_data = $this->get_post_data();
			if ( empty( $post_data['woocommerce_octifi_api_key'] ) ) {
				WC_Admin_Settings::add_error( __( 'Please enter OctiFi Public API Key', 'octifi' ) );
			} elseif ( empty( $post_data['woocommerce_octifi_private_api_key'] ) ) {
				WC_Admin_Settings::add_error( __( 'Please enter OctiFi Private API Key', 'octifi' ) );
			} else {
				foreach ( $this->get_form_fields() as $key => $field ) {
					$setting_value          = $this->get_field_value( $key, $field, $post_data );
					$this->settings[ $key ] = $setting_value;
				}
				return update_option( $this->get_option_key(), apply_filters( 'woocommerce_settings_api_sanitized_fields_' . $this->id, $this->settings ) );
			}
		}

		/**
		 * Receipt page.
		 *
		 * @param  int $order_id Order ID.
		 */
		public function octifi_receipt_page( $order_id ) {
			global $woocommerce;

			$order      = wc_get_order( $order_id );
			$order_data = $order->get_data();

			$order->delete_meta_data( 'OctiFi_Payment_Action' );
			$order->add_meta_data( 'OctiFi_Payment_Action', $this->payment_action );
			$order->save_meta_data();

			$product_name = '';
			foreach ( $order->get_items() as  $item ) {
				$product_name .= $item->get_name() . ';';
			}
			$params['product_name'] = esc_html( $product_name );

			/** V2.0.10 patch */
			if ( 'redirect' === $this->payment_type || 'hosted' === $this->payment_type ) {
				include_once OCTIFI_PLUGIN_PATH . 'templates/redirect.php';
			} else {
				include_once OCTIFI_PLUGIN_PATH . 'templates/modal.php';
			}
		}

		/**
		 * Output for the order received page.
		 */
		public function octifi_thankyou_page( $order_id ) {
			global $woocommerce;

			$order  = new WC_Order( $order_id );
			$status = $order->get_status();
			if ( 'pending' === $status ) {
				$style = 'width: 100%;  margin-bottom: 1rem; background: #00ccb8; padding: 20px; color: #fff; font-size: 22px;';
				?>
				<div class="payment-panel">
					<div style="<?php echo esc_html( $style ); ?>">
					<?php echo esc_html( __( 'Your payment status is pending, we will update the status as soon as we receive notification from LatitudePay System.', 'octifi' ) ); ?>
					</div>
				</div>
				<?php
			} elseif ( 'processing' === $status ) {
				$style = 'width: 100%;  margin-bottom: 1rem; background: green; padding: 20px; color: #fff; font-size: 22px;';
				$woocommerce->cart->empty_cart();
				?>
				<div class="payment-panel">
					<div style="<?php echo esc_html( $style ); ?>">
					<?php echo esc_html( __( 'Your payment is successful with LatitudePay System.', 'octifi' ) ); ?>
					</div>
				</div>
				<?php
			} elseif ( 'failed' === $status ) {
				$style         = 'width: 100%;  margin-bottom: 1rem; background: indianred; padding: 20px; color: #fff; font-size: 22px;';
				$error_message = '';
				if ( isset( $_GET['octifierr'] ) ) {
					$error_message = base64_decode( sanitize_text_field( $_GET['octifierr'] ) );
					$woocommerce->cart->empty_cart();
				}
				?>
				<div class="payment-panel">
					<div style="<?php echo esc_html( $style ); ?>">
					<?php echo esc_html( __( 'Your payment is failed with LatitudePay System. ', 'octifi' ) ); ?>
					<?php if ( ! empty( $error_message ) ) { ?>
						<?php echo esc_html( $error_message ); ?>
					<?php } ?>
					</div>
				</div>
				<?php
			} elseif ( 'cancelled' === $status ) {
				$style = 'width: 100%;  margin-bottom: 1rem; background: indianred; padding: 20px; color: #fff; font-size: 22px;';
				?>
				<div class="payment-panel">
					<div style="<?php echo esc_html( $style ); ?>">
					<?php echo esc_html( __( 'Your order is cancelled.', 'octifi' ) ); ?>
					</div>
				</div>
				<?php
			}
		}

		public function octifi_admin_order_details( $order ) {
			if ( $order->get_payment_method() === $this->id ) {

				$order_id = $order->get_id();

				$status_message = '';
				$status         = '';

				if ( isset( $_GET['octifi_capture'] ) ) {

					$charge_id = get_post_meta( $order_id, 'OctiFi_Charge_Id', true );
					if ( ! empty( $charge_id ) ) {

						$header = array(
							'Accept'        => 'application/json',
							'Content-Type'  => 'application/json',
							'Authorization' => 'Api-Key ' . esc_html( $this->private_api_key ),
						);

						$params = array(
							'charge_id' => esc_attr( $charge_id ),
						);

						/*
						$options2 = array(
							CURLOPT_URL => getOctifiEnv('OCTIFI_CHARGE_URL'),
							CURLOPT_RETURNTRANSFER => true,
							CURLOPT_HEADER => false,
							CURLOPT_SSL_VERIFYPEER => false,
							CURLOPT_POST => true,
							CURLOPT_POSTFIELDS => json_encode($params),
							CURLOPT_HTTPHEADER => $header
						);
						*/

						$res = wp_remote_post(
							getOctifiEnv( 'OCTIFI_CHARGE', $this->testmode, $this->select_the_country ),
							array(
								'timeout' => 45,
								'headers' => $header,
								'body'    => json_encode( $params ),
							)
						);
						if ( is_wp_error( $res ) ) {

							$status_message = $res['response']['message'];

							$status = 'error';
						} else {

							$result2 = json_decode( $res['body'], true );
							$this->log( 'trace_1' );
							$this->log( $options2 );
							$this->log( $result2 );
							if ( 200 === $result2['status_code'] ) {
								$message = $result2['message'];
								if ( 'This charge has already been captured' === $message ) {
									$status_message = $message;
									$status         = 'error';
								} else {
									$charge_status  = $result2['data']['ChargeStatus'];
									$message        = __( 'Payment successful with OctiFi(Captured). Charge Status: ' . $charge_status . '.', 'octifi' );
									$status_message = __( 'Payment Captured Successfully.', 'octifi' );
									$status         = 'success';

									$order->delete_meta_data( 'OctiFi_Captured' );
									$capture_status = 1;
									$order->add_meta_data( 'OctiFi_Captured', $capture_status );
									$order->save_meta_data();
								}
							} else {
								$message        = $result2['message'];
								$status_message = $message;
							}
						}
						$order->add_order_note( $message );
					} else {
						$status_message = __( 'Charge ID not found. ', 'octifi' );
						$status         = 'error';
					}
				}

				$capture_url = get_edit_post_link( $order_id ) . '&octifi_capture=1';

				$captured       = (int) get_post_meta( $order_id, 'OctiFi_Captured', true );
				$charge_id      = get_post_meta( $order_id, 'OctiFi_Charge_Id', true );
				$payment_action = get_post_meta( $order_id, 'OctiFi_Payment_Action', true );

				$style = 'display: inline-block;margin-top: 20px;width: 100%;max-width: 100%;overflow: hidden;border-radius: 2px; text-align:center;';

				if ( ! empty( $status_message ) ) {
					$status_style = 'display: inline-block;margin-top: 30px;width: 100%;max-width: 100%;overflow: hidden; font-weight:600;';
					if ( 'error' === $status ) {
						$status_style .= 'color: red;';
					} elseif ( 'success' === $status ) {
						$status_style .= 'color: green;';
					}
					echo '<div style="' . esc_html( $status_style ) . '">' . esc_html( $status_message ) . '</div>';
				}

				if ( 1 === $captured ) {
					$style .= 'border:3px solid green;';
					?>
				<div style="<?php echo esc_html( $style ); ?>">
					<div style="padding: 10px; font-size: 16px; color: green">
					<?php echo esc_html( __( 'LatitudePay Payment Captured.', 'octifi' ) ); ?>
					</div>
				</div>
					<?php
				} else {
					$style .= 'border:2px solid orange;';
					?>
				<div style="<?php echo esc_html( $style ); ?>">
					<div style="padding: 10px; ">
						<a href="<?php echo esc_url( $capture_url ); ?>" class="button button-primary"><?php echo esc_html( __( 'Capture LatitudePay Payment', 'octifi' ) ); ?></a>
					</div>
				</div>
					<?php
				}
			}
		}

		public function octifi_order_completed( $order_id ) {
			global $woocommerce;
			$payment_action = get_post_meta( $order_id, 'OctiFi_Payment_Action', true );

			if ( 'authorise' === $payment_action ) {
				$order = new WC_Order( $order_id );
				if ( $order->get_payment_method() === $this->id ) {
					$charge_id = get_post_meta( $order->id, 'OctiFi_Charge_Id', true );
					if ( ! empty( $charge_id ) ) {
						$header = array(
							'Accept'        => 'application/json',
							'Content-Type'  => 'application/json',
							'Authorization' => 'Api-Key ' . esc_html( $this->private_api_key ),
						);

						$params = array(
							'charge_id' => $charge_id,
						);
						$res    = wp_remote_post(
							getOctifiEnv( 'OCTIFI_CHARGE', $this->testmode, $this->select_the_country ),
							array(
								'timeout' => 45,
								'headers' => $header,
								'body'    => json_encode( $params ),
							)
						);
						if ( is_wp_error( $res ) ) {

							$message = $res['response']['message'];
						} else {

							$result2 = json_decode( $res['body'], true );
							$this->log( 'trace_2' );
							$this->log( $options2 );
							$this->log( $result2 );
							if ( 200 === $result2['status_code'] ) {
								$charge_status  = $result2['data']['ChargeStatus'];
								$message        = __( 'Payment successful with OctiFi(Captured). Charge Status: ' . $charge_status . '.', 'octifi' );
								$capture_status = 1;
								$order->add_meta_data( 'OctiFi_Captured', $capture_status );
								$order->save_meta_data();
							} else {
								$message = $result2['message'];
							}
						}
						$order->add_order_note( $message );
					}
				}
			}

		}

		public function octifi_check_ipn_response() {
			global $woocommerce;

			if ( isset( $_REQUEST['checkout'] ) ) {
				$checkout = sanitize_text_field( $_REQUEST['checkout'] );

				$search = 'success?data';
				if ( false !== strpos( $checkout, $search ) || 'success' === $checkout ) {
					if ( 'success' === $checkout ) {
						$response['checkout_token']    = isset( $_REQUEST['checkout_token'] ) ? sanitize_text_field( $_REQUEST['checkout_token'] ) : '';
						$response['merchant_order_id'] = isset( $_REQUEST['merchant_order_id'] ) ? sanitize_text_field( $_REQUEST['merchant_order_id'] ) : '';
						$response['statuscode']        = isset( $_REQUEST['statuscode'] ) ? sanitize_text_field( $_REQUEST['statuscode'] ) : '';
					} else {
						$data     = str_replace( $search, '', $checkout );
						$jsonData = base64_decode( $data );
						$response = json_decode( $jsonData, true );
					}

					$error_message = '';

					$order_id = $response['merchant_order_id'];
					$order    = new WC_Order( $order_id );

					if ( 200 === $response['statuscode'] ) {

						$checkout_token = $response['checkout_token'];

						$order->delete_meta_data( 'OctiFi_Checkout_Token' );
						$order->add_meta_data( 'OctiFi_Checkout_Token', $checkout_token );
						$order->save_meta_data();

						$header = array(
							'Accept'        => 'application/json',
							'Content-Type'  => 'application/json',
							'Authorization' => 'Api-Key ' . esc_html( $this->private_api_key ),
						);

						$is_capture = false;
						if ( 'capture' === $this->payment_action ) {
							$is_capture = true;
						}

						$params = array(
							'bill_total_amount' => $order->get_total(),
							'bill_currency'     => $order->get_currency(),
							'bill_tax_amount'   => $order->get_total_tax(),
							'is_capture'        => $is_capture,
						);
						$res    = wp_remote_post(
							getOctifiEnv( 'OCTIFI_CREATE', $this->testmode, $this->select_the_country ) . $checkout_token . '/',
							array(
								'timeout' => 45,
								'headers' => $header,
								'body'    => json_encode( $params ),
							)
						);
						if ( is_wp_error( $res ) ) {
							$error_message = $res['response']['message'];
						} else {

							$result = json_decode( $res['body'], true );
							$this->log( 'trace_3' );
							$this->log( $options );
							$this->log( $result );
							if ( 200 === $result['status_code'] ) {
								$order->delete_meta_data( 'OctiFi_Charge_Id' );
								$order->delete_meta_data( 'OctiFi_Txn_Number' );
								$order->add_meta_data( 'OctiFi_Charge_Id', $result['data']['charge_id'] );
								$order->add_meta_data( 'OctiFi_Txn_Number', $result['data']['order_payment_details']['data']['txn_number'] );
								$order->save_meta_data();

								if ( $is_capture ) {
									$params = array(
										'charge_id' => $result['data']['charge_id'],
									);

									$OctiFi_Charge_Id = $result['data']['charge_id'];
									$res              = wp_remote_get(
										getOctifiEnv( 'OCTIFI_CHARGE_DETAIL', $this->testmode, $this->select_the_country ) . $OctiFi_Charge_Id . '/',
										array(
											'timeout' => 45,
											'headers' => $header,
											'body'    => json_encode( $params ),
										)
									);
									if ( is_wp_error( $res ) ) {

										$error_message = $res['response']['message'];
									} else {

										$result2 = json_decode( $res['body'], true );
										$this->log( 'trace_4' );
										$this->log( $options2 );
										$this->log( $result2 );
										if ( 200 === $result2['status_code'] ) {
											$charge_status = $result2['data']['state'];

											$order->delete_meta_data( 'OctiFi_Captured' );
											$capture_status = 0;
											if ( 'ChargeState.CAPTURED' === $charge_status ) {
												$capture_status = 1;
											}
											$order->add_meta_data( 'OctiFi_Captured', $capture_status );
											$order->save_meta_data();

											$order->update_status( 'processing', __( 'Payment successful with OctiFi(Authorized and Captured). Charge Status: ' . $charge_status . '.', 'octifi' ) );
											wp_redirect( $this->get_return_url( $order ) );
										} else {
											$error_message = $result2['message'];
										}
									}
								} else {
									$charge_status = $result['data']['order_detail']['status'];
									$order->update_status( 'processing', __( 'Payment successful with OctiFi (Authorized). Charge Status: ' . $charge_status . '.', 'octifi' ) );
									wp_redirect( $this->get_return_url( $order ) );
								}
							} else {
								$error_message = $result['message'];
								$order->delete_meta_data( 'OctiFi_Charge_Id' );
								$order->delete_meta_data( 'OctiFi_Txn_Number' );

								if ( isset( $result['data']['charge_id'] ) ) {
									$order->add_meta_data( 'OctiFi_Charge_Id', $result['data']['charge_id'] );
								}
								if ( isset( $result['data']['order_payment_details']['data']['txn_number'] ) ) {
									$order->add_meta_data( 'OctiFi_Txn_Number', $result['data']['order_payment_details']['data']['txn_number'] );
								}
								$order->save_meta_data();
							}
						}
					} else {
						$error_message = __( 'No Checkout Token from OctiFi', 'octifi' );
					}

					if ( $error_message ) {
						wc_add_notice( __( 'Payment error: ', 'woocommerce' ) . $error_message );
						$order->update_status( 'failed', __( 'Payment Failed with OctiFi. Reason: ' . $error_message, 'octifi' ) );
						$error_message = base64_encode( $error_message );
						wp_redirect( $this->get_return_url( $order ) . '&octifierr=' . $error_message );
					}
				} else {
					$search = 'failed?data';
					if ( false !== strpos( $checkout, $search ) || 'failed' === $checkout ) {
						if ( 'failed' === $checkout ) {
							$response['errorcode']         = isset( $_REQUEST['errorcode'] ) ? sanitize_text_field( $_REQUEST['errorcode'] ) : '';
							$response['merchant_order_id'] = isset( $_REQUEST['merchant_order_id'] ) ? sanitize_text_field( $_REQUEST['merchant_order_id'] ) : '';
							$response['statuscode']        = isset( $_REQUEST['statuscode'] ) ? sanitize_text_field( $_REQUEST['statuscode'] ) : '';
						} else {
							$data     = str_replace( $search, '', $checkout );
							$jsonData = base64_decode( $data );
							$response = json_decode( $jsonData, true );
						}

						$error_message = $response['errorcode'];
						if ( is_array( $response['errorcode'] ) ) {
							$error_message = $response['errorcode'][0];
						}

						$order_id = $response['merchant_order_id'];
						$order    = new WC_Order( $order_id );
						$order->update_status( 'failed', __( 'Payment Failed with OctiFi. Reason: ' . $error_message, 'octifi' ) );

						$order->add_meta_data( 'OctiFi_Payment_Status_Code', $response['statuscode'] );
						$order->save_meta_data();

						$error_message = base64_encode( $error_message );
						wp_redirect( $this->get_return_url( $order ) . '&octifierr=' . $error_message );
					}
				}
			}
			exit;
		}

		/**
		 * Process the payment and return the result.
		 *
		 * @param int $order_id
		 * @return array
		 */
		public function process_payment( $order_id ) {
			$order = wc_get_order( $order_id );
			return array(
				'result'   => 'success',
				'redirect' => $order->get_checkout_payment_url( true ),
			);
		}

		public function octifi_get_site_logo() {
			$custom_logo_id = get_theme_mod( 'custom_logo' );
			$image          = wp_get_attachment_image_src( $custom_logo_id, 'full' );
			return $image[0];
		}

		public function log( $content ) {
			$debug = OCTIFI_DEBUG;
			if ( true === $debug ) {
				$file = OCTIFI_PLUGIN_PATH . 'debug.log';
				$fp   = fopen( $file, 'a+' );
				fwrite( $fp, "\n" );
				fwrite( $fp, gmdate( 'Y-m-d H:i:s' ) . ': ' );
				fwrite( $fp, print_r( $content, true ) );
				fclose( $fp );
			}
		}
	}
}

add_filter( 'woocommerce_payment_gateways', 'octififunction_add_octifi_gateway_class' );
function octififunction_add_octifi_gateway_class( $methods ) {
	$methods[] = 'WC_OctiFi';
	return $methods;
}

add_filter( 'woocommerce_available_payment_gateways', 'octififunction_enable_octifi_gateway' );
function octififunction_enable_octifi_gateway( $available_gateways ) {
	if ( is_admin() ) {
		return $available_gateways;
	}

	if ( isset( $available_gateways['octifi'] ) ) {
		$settings = get_option( 'woocommerce_octifi_settings' );

		if ( empty( $settings['api_key'] ) ) {
			unset( $available_gateways['octifi'] );
		}
		if ( empty( $settings['private_api_key'] ) ) {
			unset( $available_gateways['octifi'] );
		}
	}
	return $available_gateways;
}
add_action( 'woocommerce_checkout_order_review', 'octififunction_woocommrece_checkout_text' );

function octififunction_woocommrece_checkout_text() {
	global $woocommerce;
	$amount2      = floatval( preg_replace( '#[^\d.]#', '', WC()->cart->total ) );
	$final_amount = $amount2 / 3;
	$final_amount = round( $final_amount, 2 );
	?>
<!-- final amount conversion input -->
	<input type="hidden" value="<?php echo esc_attr( $final_amount ); ?>" id="final_amount" />
<!--Creates the popup body-->
<div class="modal-ocitifi">

	<div class="moda-ocitifi-dialog">
		<div class="modal-content-wrap">
			<div class="popup-overlay">
				<!--Creates the popup content-->
				<div class="popup-content">
					<a href="#" class="close-btn">X</a>
					<div class="top-head-image">
						<center>
						<img src="<?php echo esc_url( OCTIFI_PLUGIN_URL ); ?>assets/images/logo.png" class="img-fluid" alt="logo"></center>
						<h5 class="head-title">Be the savvy customer and choose LatitudePay at checkout</h5>
					</div>
					<div class="cstm-row">
						<div class="cstm-col">
							<div class="checkout-card">
								<img src="<?php echo esc_url( OCTIFI_PLUGIN_URL ); ?>assets/images/Pay-only-1_3-today-icon.gif" class="img-fluid" alt="card-img" style="display: initial;">
								<h6>Pay only one <br>instalment today</h6>
								<p>Split your payments into <br> 3, 6 and 12 months affordable instalments.<br><b>Always 0% interest and <br>no hidden fees.</b></p>
							</div>
						</div>

						<div class="cstm-col">
							<div class="checkout-card  both-debit">
								<img src="<?php echo esc_url( OCTIFI_PLUGIN_URL ); ?>assets/images/Usebothcreditn debitcard.gif" class="img-fluid" alt="card-img" style="display: initial;">
								<h6>Use both debit <br>or credit card</h6>
								<p>No credit card? No Problem! We accept any 
								<?php
								if ( 1 === $settings['select_the_country'] ) {
									?>
									Singapore 
									<?php
								} else {
									echo 'Malaysia'; }
								?>
								bank issued debit cards</p>
							</div>
						</div>

						<!-- <div class="cstm-col">
							<div class="checkout-card">
								<img src="<?php echo esc_url( OCTIFI_PLUGIN_URL ); ?>assets/images/Earncashbackicon.gif" class="img-fluid" alt="card-img">
								<h6>Earn 1.5% cashback </h6>
								<p>Have more cash to spare? Pay more upfront and earn additional 1.5% cashback from us!</p>
							</div>
						</div> -->
					</div>
					<div class="footer-title">
						<h5 class="head-title">Pay with your preferred payment methods</h5>
						<ul class="payment-img">
							<li><img src="<?php echo esc_url( OCTIFI_PLUGIN_URL ); ?>assets/images/visa.png"></li>
							<li><img src="<?php echo esc_url( OCTIFI_PLUGIN_URL ); ?>assets/images/mastercard.png"></li>
							<li class="american-img"><img src="<?php echo esc_url( OCTIFI_PLUGIN_URL ); ?>assets/images/American-express.png"></li>
						</ul>
						<div class="link-footer">
							<p>Terms and Condition Applies.<a href="
							<?php
							if ( 1 === $settings['select_the_country'] ) {
								echo 'https://octifi.com/paylater_terms/';
							} elseif ( 2 === $settings['select_the_country'] ) {
								echo 'https://my.latitudepay.com/paylater_terms/';
							} else {
								echo 'https://octifi.com/paylater_terms/';}
							?>
							" target="_blank" style="text-decoration: none;">See full T & -c here >></a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
	<?php
} add_action( 'woocommerce_review_order_before_shipping', 'octififunction_shipping' );
function octififunction_shipping() {
	global $woocommerce;
	$amount2       = floatval( preg_replace( '#[^\d.]#', '', WC()->cart->total ) );
	$final_amount  = $amount2 / 3;
	$final_amount1 = round( $final_amount, 2 );
	?>
<script type="text/javascript">
		var value="<?php echo esc_attr( $final_amount1 ); ?>";
	jQuery('#final_amount').val(value);
	jQuery("#checkout-newpayment").text(value);
	jQuery(".shipping_method").on("click", function(){

	console.log("<?php echo esc_attr( $final_amount1 ); ?>");
		var value1="<?php echo esc_attr( $final_amount1 ); ?>";
	jQuery('#final_amount').val(value1);
	});

	</script>
	<?php
}

// Add Custom Content Before 'Add To Cart' Button On Product Page
function octififunction_my_content( $content ) {

	$settings = get_option( 'woocommerce_octifi_settings' );

	?>


<!--Creates the popup body-->
<div class="modal-ocitifi">
	<div class="moda-ocitifi-dialog">
		<div class="modal-content-wrap">
			<div class="popup-overlay">
				<!--Creates the popup content-->
				<div class="popup-content">
					<a href="#" class="close-btn">X</a>
					<div class="top-head-image">
						<center>
						<img src="<?php echo esc_url( OCTIFI_PLUGIN_URL ); ?>assets/images/logo.png" class="img-fluid" alt="logo"></center>
						<h5 class="head-title">Be the savvy customer and choose LatitudePay at checkout</h5>
					</div>
					<div class="cstm-row">
						<div class="cstm-col">
							<div class="checkout-card">
								<img src="<?php echo esc_url( OCTIFI_PLUGIN_URL ); ?>assets/images/Pay-only-1_3-today-icon.gif" class="img-fluid" alt="card-img" style="display: initial;">
								<h6>Pay only one <br>instalment today</h6>
								<p>Split your payments into <br> 3, 6 and 12 months affordable instalments.<br><b>Always 0% interest and <br>no hidden fees.</b></p>
							</div>
						</div>
						<div class="cstm-col">
							<div class="checkout-card  both-debit">
								<img src="<?php echo esc_url( OCTIFI_PLUGIN_URL ); ?>assets/images/Usebothcreditn debitcard.gif" class="img-fluid" alt="card-img" style="display: initial;">
								<h6>Use both debit<br> or credit card</h6>
								<p>No credit card? <br>No Problem! <br>We accept any 
								<?php
								if ( 1 === $settings['select_the_country'] ) {
									?>
									Singapore<br> 
									<?php
								} else {
									echo 'Malaysia'; }
								?>
								bank issued debit cards</p>
							</div>
						</div>
						<!-- <div class="cstm-col">
							<div class="checkout-card">
								<img src="<?php echo esc_url( OCTIFI_PLUGIN_URL ); ?>assets/images/Earncashbackicon.gif" class="img-fluid" alt="card-img">
								<h6>Earn 1.5% cashback </h6>
								<p>Have more cash to spare? Pay more upfront and earn additional 1.5% cashback from us!</p>
							</div>
						</div> -->
					</div>
					<div class="footer-title">
						<h5 class="head-title">Pay with your preferred payment methods</h5>
						<ul class="payment-img">
							<li><img src="<?php echo esc_url( OCTIFI_PLUGIN_URL ); ?>assets/images/visa.png"></li>
							<li><img src="<?php echo esc_url( OCTIFI_PLUGIN_URL ); ?>assets/images/mastercard.png"></li>
							<li class="american-img"><img src="<?php echo esc_url( OCTIFI_PLUGIN_URL ); ?>assets/images/American-express.png"></li>
						</ul>
						<div class="link-footer">
							<p>Terms and Condition Applies.<a href="
							<?php
							if ( 1 === $settings['select_the_country'] ) {
								echo 'https://octifi.com/paylater_terms/';
							} elseif ( 2 === $settings['select_the_country'] ) {
								echo 'https://my.latitudepay.com/paylater_terms/';
							} else {
								echo 'https://octifi.com/paylater_terms/';}
							?>
							" target="_blank" style="text-decoration: none;">See full T&C here >></a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

	<?php
	$product = wc_get_product( get_the_ID() );
	if ( $product ) {

		$thePrice             = $product->get_price();
		$my_amount2           = floatval( preg_replace( '#[^\d.]#', '', $thePrice ) );
		$final_amount_product = $my_amount2 / 3;
		$final_amount_product = esc_attr( round( $final_amount_product, 2 ) );

		$type_product = $product->get_type();

		if ( 'simple' == $type_product || 'grouped' == $type_product || 'external' == $type_product ) {
			$thePrice     = $product->get_price();
			$custom_value = get_option( 'my_field', '' );
			$admin_set    = $custom_value;
			if ( $thePrice <= $admin_set ) {
				return false;
			} else {
				$my_amount2           = floatval( preg_replace( '#[^\d.]#', '', $thePrice ) );
				$final_amount_product = $my_amount2 / 3;
				$final_amount_product = esc_attr( round( $final_amount_product, 2 ) );

			}

			$show_message = 0;
			if ( isset( $settings['min_sum'] ) && '' !== $settings['min_sum'] ) {
				$min_sum = (float) $settings['min_sum'];

				if ( (float) $thePrice > $min_sum ) {
					$show_message = 1;
				}
			} else {
				$show_message = 1;
			}

			// hide_text settings processing
			if ( 'yes' == $settings['hide_text'] || ! $settings['hide_text'] ) {
				$show_message = 0;
			}
		} elseif ( 'variable' == $type_product ) {

			$formatted_price      = (float) $product->get_variation_price( 'max' );
			$final_amount_product = $formatted_price / 3;
			$final_amount_product = esc_attr( round( $final_amount_product, 2 ) );

		}
	}

		$show_message = 0;
	if ( isset( $settings['min_sum'] ) && '' !== $settings['min_sum'] ) {
		$min_sum = (float) $settings['min_sum'];
		if ( (float) $formatted_price > $min_sum ) {
			$show_message = 1;
		}
	} else {
		$show_message = 1;
	}

		// hide_text settings processing.
	if ( 'yes' == $settings['hide_text'] || ! $settings['hide_text'] ) {
		$show_message = 0;
	}
	if ( $settings['min_sum'] <= $product->get_price() ) {
			$msgdata = '1';
	} else {
		$msgdata = '0';
	}

	if ( is_product() & 'yes' == $settings['enabled'] & 1 == $msgdata ) {

		echo '<p class="checkout-text-octifi">or 3 payments of ' . esc_html( get_woocommerce_currency_symbol() ) . '<span id="checkout-newpayment">' . esc_attr( $final_amount_product ) . '</span> or lower in <span id="OpenDialog">6 or 12 payments</span> with <img src="' . esc_url( OCTIFI_PLUGIN_URL ) . 'assets/images/logo.png" style="width:50px; margin: 0px auto;"></p>';

	}
}
add_filter( 'woocommerce_before_add_to_cart_quantity', 'octififunction_my_content', 10, 2 );

add_action( 'woocommerce_after_shop_loop_item', 'octififunction_custom_field_display_below_title', 2 );
function octififunction_custom_field_display_below_title() {

  $settings = get_option( 'woocommerce_octifi_settings' );

  $product      = wc_get_product( get_the_ID() );
  $type_product = $product->get_type();

  if ( 'simple' == $type_product || 'grouped' == $type_product || 'external' == $type_product ) {
    $thePrice     = $product->get_price();
    $custom_value = get_option( 'my_field', '' );
    $admin_set    = $custom_value;
    if ( $thePrice <= $admin_set ) {
      return false;
    } else {
      $my_amount2           = floatval( preg_replace( '#[^\d.]#', '', $thePrice ) );
      $final_amount_product = $my_amount2 / 3;
      $final_amount_product = round( $final_amount_product, 2 );

      $show_message = 0;
      if ( isset( $settings['min_sum'] ) && '' !== $settings['min_sum'] ) {
        $min_sum = (float) $settings['min_sum'];
        if ( $thePrice > $min_sum ) {
          $show_message = 1;
        }
      } else {
        $show_message = 1;
      }

      if ( 'yes' == $settings['hide_text_homepage'] || ! $settings['hide_text_homepage'] ) {
        $show_message = 0;
      } else {
        $show_message = 1;
      }
      if ( $settings['min_sum'] <= $product->get_price() ) {
        $msgdata = '1';
      } else {
        $msgdata = '0';
      }

      if ( 1 == $show_message & 'yes' == $settings['enabled'] & 1 == $msgdata ) {

        echo '<p class="checkout-text-octifi">or 3 payments of ' . esc_html( get_woocommerce_currency_symbol() ) . '<span id="checkout-newpayment">' . esc_attr( $final_amount_product ) . '</span> or lower in 6 or 12 payments with <img src="' . esc_url( OCTIFI_PLUGIN_URL ) . 'assets/images/logo.png" style="width:50px; margin: 0px auto;"></p>';
      }
    }
  } elseif ( 'variable' == $type_product ) {

    $formatted_price = $product->get_variation_price( 'max' );
    $thePrice        = number_format( $formatted_price, 0, ' ', '.' );
    $custom_value    = get_option( 'my_field', '' );
    $admin_set       = $custom_value;
    if ( $thePrice <= $admin_set ) {
      return false;
    } else {
      $my_amount2           = (float) ( $formatted_price );
      $final_amount_product = $my_amount2 / 3;
      $final_amount_product = round( $final_amount_product, 2 );

      $show_message = 0;
      if ( isset( $settings['min_sum'] ) && '' !== $settings['min_sum'] ) {
        $min_sum = (float) $settings['min_sum'];
        if ( $thePrice > $min_sum ) {
          $show_message = 1;
        }
      } else {
        $show_message = 1;
      }

      // hide_text settings processing
      if ( 'yes' == $settings['hide_text'] || ! $settings['hide_text'] ) {
        $show_message = 0;
      }

      if ( 1 == $show_message ) {
        echo '<p class="checkout-text-octifi">or 3 payments of ' . esc_html( get_woocommerce_currency_symbol() ) . '<span id="checkout-newpayment">' . esc_attr( $final_amount_product ) . '</span> or lower in <span id="OpenDialog">6 or 12 payments</span> with <img src="' . esc_url( OCTIFI_PLUGIN_URL ) . 'assets/images/logo.png" style="width:50px; margin: 0px auto;" ></p>';
      }
    }
  }
}

add_filter( 'woocommerce_available_payment_gateways', 'octififunction_checkout_payment_check' );

function octififunction_checkout_payment_check( $available_payment_gateways ) {

	global $woocommerce;

	$cart = $woocommerce->cart;
	if ( isset( $woocommerce->cart->total ) ) {
		$cart_total = $woocommerce->cart->total;
	} else {
		$cart_total = '';
	}
	$custom_value = get_option( 'my_field', '' );
	$admin_set    = $custom_value;
	if ( $cart_total <= $admin_set ) {
		if ( isset( $available_payment_gateways['octifi'] ) ) {
			unset( $available_payment_gateways['octifi'] );
		}
	}
	return $available_payment_gateways;
}

add_filter( 'admin_init', 'octififunction_my_general_settings_register_fields' );
function octififunction_my_general_settings_register_fields() {
	register_setting( 'general', 'my_field', 'esc_attr' );
	add_settings_field( 'my_field', '<label for="my_field">' . __( 'Octifi Value', 'my_field' ) . '</label>', 'octififunction_my_general_settings_fields_html', 'general' );
}

function octififunction_my_general_settings_fields_html() {
	$value = get_option( 'my_field', '' );
	echo '<input type="text" id="my_field" name="my_field" value="' . esc_html( $value ) . '" />';
}

function octifi_my_plugin_settings_link( $links ) {
	$url           = get_admin_url() . 'admin.php?page=wc-settings&tab=checkout&section=octifi';
	$settings_link = '<a href='.esc_url( $url ).'>Settings</a>';
	array_unshift( $links, $settings_link );
	return $links;
}
$plugin_cotifi = plugin_basename( __FILE__ );
add_filter( "plugin_action_links_$plugin_cotifi", 'octifi_my_plugin_settings_link' );

function octifi_pw_load_scripts() {
	wp_register_script( 'octifi_custom_js', plugins_url( '/assets/js/custom.js', __FILE__ ), array( 'jquery' ), wp_get_theme()->get( 'Version' ), 'all' );
	wp_enqueue_script( 'octifi_custom_js' );

}
add_action( 'admin_enqueue_scripts', 'octifi_pw_load_scripts' );

function octifi_add_lpay_cusrrency_settings( $settings ) {
	// Search array for the id you want.
	$symb = get_woocommerce_currency();
	global $wpdb;
	if ( 'SGD' === $symb ) {
		$val = 1;
	} elseif ( 'MYR' === $symb ) {
		$val = 2;
	} else {
		$val = 1;
	}
	$qry                          = $wpdb->get_var( "SELECT option_value FROM wp_options WHERE option_name = 'woocommerce_octifi_settings' " );
	$column                       = unserialize( $qry );
	$column['select_the_country'] = esc_attr( $val );
	$str                          = serialize( $column );

	$wpdb->query( $wpdb->prepare( "UPDATE $wpdb->prefix.' '.options SET option_value = %s WHERE option_name = 'woocommerce_octifi_settings' ", $$str ) );

	$key              = array_search( 'woocommerce_currency', array_column( $settings, 'id' ) ) + 1;
	$custom_setting[] = array(
		'id'      => 'woocommerce_octifi_select_the_country',
		'default' => '',
		'type'    => 'hidden',
	);

	// Merge with existing settings at the specified index
	$new_settings = array_merge( array_slice( $settings, 0, $key ), $custom_setting, array_slice( $settings, $key ) );
	return $new_settings;
}
add_filter( 'woocommerce_general_settings', 'octifi_add_lpay_cusrrency_settings' );
