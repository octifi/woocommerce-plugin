jQuery( document ).ready(function( $ ) {
	var rval1= $('#final_amount').val();
	jQuery("#checkout-newpayment").text(rval1);
	
	//console.log('payment method '+jQuery('input[name="payment_method"]:checked').val());
	if(jQuery('input[name="payment_method"]:checked').val() == 'octifi'){
		setInterval(function(){
			var sim1= $('#final_amount').val();
			jQuery("#checkout-newpayment").text(sim1);
		},1000); 
	}else{
		jQuery(document).on('change','input[name="payment_method"]',function(){
			if(jQuery(this).val() == 'octifi'){
				setInterval(function(){
				  var rval= $('#final_amount').val();
				  jQuery("#checkout-newpayment").text(rval);
				},1000);
			}
		});	 
	}
jQuery('body').on('click','#shipping_method',function(){	
		$(document.body).trigger('.final_amount').trigger('wc_fragment_refresh');
				var pp1= $('#final_amount').val();
				setInterval(function(){
			var sim1= $('#final_amount').val();
			jQuery("#checkout-newpayment").text(sim1);
		},1000);
});	
	jQuery( document ).ready(function() {
    var rval= $('#final_amount').val();
	jQuery("#checkout-newpayment").text(rval);
});
    //jQuery(".payment_box p").on("click", function() {
    jQuery('body').on('click','#OpenDialog',function(){	
        //console.log('clciked');
        jQuery('body').append('<div class="octify-modal-backdrop fade show"></div>');
        jQuery(".popup-overlay, .popup-content").addClass("active");
        jQuery(".modal-ocitifi").addClass("show");
    });
	/*
    jQuery('body').on('click','#OpenDialog',function(){	
       // console.log('clciked');
        jQuery("body").addClass("popup-new");
    	jQuery(".popup-overlay, .popup-content").addClass("active");
        
    });
	*/

    //removes the "active" class to .popup and .popup-content when the "Close" button is clicked 

    jQuery(document).on('click','.octify-modal-backdrop',function(){
        jQuery(".popup-overlay, .popup-content").removeClass("active");
        jQuery(".modal-ocitifi").removeClass("show");
        jQuery(this).remove();	
    });

    jQuery(document).on('click','.close-btn',function(){
        jQuery(".popup-overlay, .popup-content").removeClass("active");
        jQuery(".modal-ocitifi").removeClass("show");
        jQuery("body").removeClass("popup-new");
        jQuery(".octify-modal-backdrop").remove();	
    });
});

/*
jQuery( document ).ready(function() {
	jQuery('body').on('click','#OpenDialog',function(){ 
		//console.log('clciked');
	  	jQuery('body').append('<div class="modal-backdrop fade show"></div>');
	  	jQuery(".popup-overlay, .popup-content").addClass("active");
	   jQuery(".modal-ocitifi").addClass("show");
	  
	});
	
	jQuery('body').on('click','#OpenDialog',function(){ 
		//console.log('clciked');
		 jQuery("body").addClass("popup-new");
	  	jQuery(".popup-overlay, .popup-content").addClass("active");
		
	});
	
	
	//removes the "active" class to .popup and .popup-content when the "Close" button is clicked 
	
	
	jQuery(document).on('click','.modal-backdrop',function(){
		jQuery(".popup-overlay, .popup-content").removeClass("active");
		jQuery(".modal-ocitifi").removeClass("show");
		jQuery(this).remove();  
	});
	
	jQuery(document).on('click','.close-btn',function(){
		jQuery(".popup-overlay, .popup-content").removeClass("active");
		jQuery(".modal-ocitifi").removeClass("show");
		jQuery("body").removeClass("popup-new");
		jQuery(".modal-backdrop").remove(); 
	});
});
*/
